//npm install --save moment
//npm install @types/googlemaps --save
//npm install @agm/core @ng-bootstrap/ng-bootstrap --
//npm i @angular/youtube-player@13.1.1
//npm i @swimlane/ngx-charts --save 

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AgmCoreModule, GoogleMapsAPIWrapper } from '@agm/core';
import { YouTubePlayerModule } from '@angular/youtube-player';

import { AppRoutingModule } from './app-routing.module';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule} from '@angular/material/button';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { ButtonComponent } from './components/button/button.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchPanelComponent } from './components/search-panel/search-panel.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import { HomePageComponent } from './components/home-page/home-page.component';
import { LoginComponent } from './components/login/login.component';
import {MatCardModule} from '@angular/material/card';
import { RegisterComponent } from './components/register/register.component';
import { ListOfServiceProvidersComponent } from './components/list-of-service-providers/list-of-service-providers.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateAccountComponent } from './components/update-account/update-account.component';
import { ManageAppointmentsComponent } from './components/manage-appointments/manage-appointments.component';
import { MatTableModule } from '@angular/material/table';
import { RescheduleAppointmentComponent } from './components/reschedule-appointment/reschedule-appointment.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { PreviousAppointmentsComponent } from './components/previous-appointments/previous-appointments.component';
import { MakePaymentComponent } from './components/make-payment/make-payment.component';
import { PaymentInfoComponent } from './components/payment-info/payment-info.component';
import { ScheduleAppointmentComponent } from './components/schedule-appointment/schedule-appointment.component';
import { CartComponent } from './components/cart/cart.component';
import { RegisterServiceComponent } from './components/register-service/register-service.component';
import { UnregisterServiceComponent } from './components/unregister-service/unregister-service.component';
import { FutureAppointmentsComponent } from './components/future-appointments/future-appointments.component';
import { WriteReviewComponent } from './components/write-review/write-review.component';
import { InstructionalVideosComponent } from './components/instructional-videos/instructional-videos.component';
import { MostPopularComponent } from './components/most-popular/most-popular.component';
import {MatGridListModule} from '@angular/material/grid-list';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { ViewReviewsComponent } from './components/view-reviews/view-reviews.component';
import { RespondToReviewsComponent } from './components/respond-to-reviews/respond-to-reviews.component';
import { DataAnalyticsComponent } from './components/data-analytics/data-analytics.component';
import { HardwareStoresComponent } from './components/hardware-stores/hardware-stores.component';
import { FutureAppointmentsByDayComponent } from './components/future-appointments-by-day/future-appointments-by-day.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { LargeBarChartComponent } from './components/large-bar-chart/large-bar-chart.component';
import { RecommendedItemsComponent } from './components/recommended-items/recommended-items.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ButtonComponent,
    DropdownComponent,
    SearchPanelComponent,
    HomePageComponent,
    LoginComponent,
    RegisterComponent,
    ListOfServiceProvidersComponent,
    UpdateAccountComponent,
    ManageAppointmentsComponent,
    RescheduleAppointmentComponent,
    PreviousAppointmentsComponent,
    MakePaymentComponent,
    PaymentInfoComponent,
    ScheduleAppointmentComponent,
    CartComponent,
    RegisterServiceComponent,
    UnregisterServiceComponent,
    FutureAppointmentsComponent,
    WriteReviewComponent,
    InstructionalVideosComponent,
    MostPopularComponent,
    BarChartComponent,
    ViewReviewsComponent,
    RespondToReviewsComponent,
    DataAnalyticsComponent,
    HardwareStoresComponent,
    FutureAppointmentsByDayComponent,
    LineChartComponent,
    LargeBarChartComponent,
    RecommendedItemsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatMenuModule,
    MatFormFieldModule,
    MatButtonModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    HttpClientModule,
    FormsModule,
    MatTableModule,
    MatDatepickerModule,
    MatNativeDateModule,
    NgxMaterialTimepickerModule,
    MatGridListModule,
    YouTubePlayerModule,
    NgxChartsModule,
    AgmCoreModule.forRoot({apiKey: 'AIzaSyC4sKcbotnuQvWcr5aYuyVDWA3HWnFtCpA'+ '&libraries=visualization'}),
  ],
  providers: [GoogleMapsAPIWrapper],
  bootstrap: [AppComponent]
})
export class AppModule { }
