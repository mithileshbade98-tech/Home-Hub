import {Option} from './types/Option'

export const DO_IT_YOURSELF: Option[] = [
    {
        id: 'directions_to_hardware_store',
        name: 'Directions To Hardware Store',
    },
    {
        id: 'instructional_videos',
        name: 'Instructional Videos',
    },
]