import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from 'src/app/types/User';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  users: User[];
  currentUserType: string = "None";
  currentUserName: string;

  private currentUserTypeChange: BehaviorSubject<string>;

  chosenVideoType: string;

  constructor(private http: HttpClient) { 
    this.currentUserTypeChange = new BehaviorSubject<string>(null);
  }

  setUserType(type: string){
    this.currentUserTypeChange.next(type);
  }

  getUserType(){
    return this.currentUserTypeChange.asObservable();
  }

  uri = 'http://localhost:4000';

  findUsers() {
    return this.http.get(`${this.uri}/find-users`);
  }

  findUser(username: string, password: string) {
    const find_user_with = {
      username: username,
      password: password
    }

    JSON.stringify(find_user_with, null, 2);

    return this.http.post(`${this.uri}/find-user`, find_user_with, httpOptions);
  }

  addUser(username: string, password: string, type: string, streetaddress: string, city: string,
    state: string, zipcode: number, email: string, phonenumber: number) {
      const add_user_with = {
        username: username,
        password: password,
        type: type,
        streetaddress: streetaddress,
        city: city,
        state: state, 
        zipcode: zipcode,
        email: email,
        phonenumber: phonenumber
      }

      JSON.stringify(add_user_with, null, 2);

      return this.http.post(`${this.uri}/add-user`, add_user_with, httpOptions);
  }

  getUserInfo(username: string) {
    const find_user_with = {
      username: username,
    }

    JSON.stringify(find_user_with, null, 2);

    return this.http.post(`${this.uri}/get-user-info`, find_user_with, httpOptions);
  }

  updateUser(username: string, password: string, type: string, streetaddress: string, city: string,
    state: string, zipcode: number, email: string, phonenumber: number) {
      const add_user_with = {
        username: username,
        password: password,
        type: type,
        streetaddress: streetaddress,
        city: city,
        state: state, 
        zipcode: zipcode,
        email: email,
        phonenumber: phonenumber
      }

      JSON.stringify(add_user_with, null, 2);

      return this.http.post(`${this.uri}/update-user`, add_user_with, httpOptions);
  }

  getUserAddress(username: string){
    const get_user_address_with = {
      username: username,
    }

    JSON.stringify(get_user_address_with, null, 2);

    return this.http.post(`${this.uri}/get-user-address`, get_user_address_with, httpOptions);
  }

  checkIfUserExists(username: string){ 
    const check_if_user_exists_with = {
      username: username,
    }

    JSON.stringify(check_if_user_exists_with, null, 2);

    return this.http.post(`${this.uri}/check-if-user-exists`, check_if_user_exists_with, httpOptions);
  }

  getVideoIds(type: string){
    const get_video_ids_with = {
      type: type,
    }

    JSON.stringify(get_video_ids_with, null, 2);

    return this.http.post(`${this.uri}/get-video-ids`, get_video_ids_with, httpOptions);
  }

  addReview(serviceProvider: string, customer: string, service: string, rating: number, reviewText: string){
    const add_review_with = {
      serviceProvider: serviceProvider,
      customer: customer,
      service: service,
      rating: rating,
      reviewText: reviewText
    }
    //console.log(add_review_with);
    
    JSON.stringify(add_review_with, null, 2);

    return this.http.post(`${this.uri}/add-review`, add_review_with, httpOptions);
  }

  addUserLocation(userType: string, userName: string, latitude: number, longitude: number){
    if(userType == "Customer"){
      const add_user_location_with = {
        username: userName,
        latitude: latitude,
        longitude: longitude
      }
      
      JSON.stringify(add_user_location_with, null, 2);
  
      return this.http.post(`${this.uri}/add-customer-location`, add_user_location_with, httpOptions);
    }
    else{
      const add_user_location_with = {
        username: userName,
        latitude: latitude,
        longitude: longitude
      }
      
      JSON.stringify(add_user_location_with, null, 2);
  
      return this.http.post(`${this.uri}/add-service-provider-location`, add_user_location_with, httpOptions);
    }
  }

}
