export interface Review{
    service: string,
    rating: string,
    customer: string,
    review_text: string,
    date: string,
    service_provider: string,
    response: string;
    _id: string;
}