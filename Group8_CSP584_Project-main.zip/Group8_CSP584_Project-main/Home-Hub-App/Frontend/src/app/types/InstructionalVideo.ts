export interface InstructionalVideo{
    videoId: string;
    type: string;
}