export interface Option{
    id: string;
    name: string;
}