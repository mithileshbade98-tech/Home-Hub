import { Service } from "./Service";

export interface User{
    type: string,
    name: string,
    password: string,
    streetAddress: string,
    city: string,
    state: string,
    zipCode: number,
    email: string,
    phoneNumber: number
}

export interface Customer extends User{

}

export interface ServiceProvider extends User, Service{
    rating: number,
    review_count: number
}