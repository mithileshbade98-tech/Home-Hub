
export interface Service{
    service: string,
    costPerHour: number,
    serviceName: string
}