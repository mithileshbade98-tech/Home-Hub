export interface UserType{
    value: string,
    viewValue: string
}