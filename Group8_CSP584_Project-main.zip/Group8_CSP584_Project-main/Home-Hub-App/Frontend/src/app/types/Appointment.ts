import { Time } from "@angular/common"
import { Service } from "./Service"

export interface Appointment extends Service{
    dayServicePerformed: Date,
	displayDayServicePerformed: string,
	serviceStartTime: Time,
	displayServiceStartTime: string,
	serviceEndTime: Time,
	displayServiceEndTime: string,
	serviceProvider: string,
	customer: string,
	serviceCost: number,
	amountDue: number,
	streetAddress: string,
	city: string,
	state: string,
	zipCode: number

}