export interface HardwareStore{
    storeName: string,
    streetAddress: string,
    city: string,
    state: string,
    zipCode: number,
    phoneNumber: number
    rating: number,
    review_count: number,
    latitude: number,
    longitude: number
}