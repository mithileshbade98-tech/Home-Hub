import {Option} from './types/Option'

export const EXTERIOR_OPTIONS: Option[] = [
    {
        id: 'garage_door_services',
        name: 'Garage Doors',
    },
    {
        id: 'gutter_services',
        name: 'Gutter Services',
    },
    {
        id: 'masonry_concrete',
        name: 'Masonry/Concrete',
    },
    {
        id: 'roofing',
        name: 'Roofing',
    },
    {
        id: 'locksmith',
        name: 'Locksmith',
    },

]