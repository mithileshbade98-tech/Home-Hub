import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './components/cart/cart.component';
import { DataAnalyticsComponent } from './components/data-analytics/data-analytics.component';
import { FutureAppointmentsByDayComponent } from './components/future-appointments-by-day/future-appointments-by-day.component';
import { FutureAppointmentsComponent } from './components/future-appointments/future-appointments.component';
import { HardwareStoresComponent } from './components/hardware-stores/hardware-stores.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { InstructionalVideosComponent } from './components/instructional-videos/instructional-videos.component';
import { ListOfServiceProvidersComponent } from './components/list-of-service-providers/list-of-service-providers.component';
import { LoginComponent } from './components/login/login.component';
import { MakePaymentComponent } from './components/make-payment/make-payment.component';
import { ManageAppointmentsComponent } from './components/manage-appointments/manage-appointments.component';
import { PaymentInfoComponent } from './components/payment-info/payment-info.component';
import { PreviousAppointmentsComponent } from './components/previous-appointments/previous-appointments.component';
import { RegisterServiceComponent } from './components/register-service/register-service.component';
import { RegisterComponent } from './components/register/register.component';
import { RescheduleAppointmentComponent } from './components/reschedule-appointment/reschedule-appointment.component';
import { RespondToReviewsComponent } from './components/respond-to-reviews/respond-to-reviews.component';
import { ScheduleAppointmentComponent } from './components/schedule-appointment/schedule-appointment.component';
import { UnregisterServiceComponent } from './components/unregister-service/unregister-service.component';
import { UpdateAccountComponent } from './components/update-account/update-account.component';
import { ViewReviewsComponent } from './components/view-reviews/view-reviews.component';
import { WriteReviewComponent } from './components/write-review/write-review.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'home-page', component: HomePageComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'list-of-service-providers', component: ListOfServiceProvidersComponent },
  { path: 'update-account', component: UpdateAccountComponent },
  { path: 'manage-appointments', component: ManageAppointmentsComponent },
  { path: 'reschedule-appointment', component: RescheduleAppointmentComponent },
  { path: 'previous-appointments', component: PreviousAppointmentsComponent },
  { path: 'make-payment', component: MakePaymentComponent },
  { path: 'payment-info', component: PaymentInfoComponent },
  { path: 'schedule-appointment', component: ScheduleAppointmentComponent },
  { path: 'cart', component: CartComponent },
  { path: 'register-service', component: RegisterServiceComponent },
  { path: 'unregister-service', component: UnregisterServiceComponent },
  { path: 'future-appointments', component: FutureAppointmentsComponent },
  { path: 'write-review', component: WriteReviewComponent },
  { path: 'instructional-videos', component: InstructionalVideosComponent },
  { path: 'view-reviews', component: ViewReviewsComponent },
  { path: 'respond-to-reviews', component: RespondToReviewsComponent },
  { path: 'data-analytics', component: DataAnalyticsComponent },
  { path: 'future-appointments-by-day', component: FutureAppointmentsByDayComponent},
  { path: 'hardware-stores', component: HardwareStoresComponent }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
 }
