import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { ServiceProvider } from 'src/app/types/User';
import { UsersService } from 'src/app/users.service';


@Component({
  selector: 'app-list-of-service-providers',
  templateUrl: './list-of-service-providers.component.html',
  styleUrls: ['./list-of-service-providers.component.css']
})
export class ListOfServiceProvidersComponent implements OnInit {

  serviceProviders: ServiceProvider[];
  serviceType: string;
  userType: string = null;

  yelpRatings: any[] = [];
  yelpRatingDataLoading: boolean = false;

  constructor(private userService : UsersService, private serviceProviderService: ServiceProvidersService, private router : Router) { 
    this.yelpRatingDataLoading = true;
  }

  displayedColumns: string[] = ['serviceProvider', 'service', 'streetAddress', 'city', 'state', 'zipCode','rating', 'numberOfReviews', 'costPerHour', 'scheduleAppointment'];

  ngOnInit(): void {
    this.setupPage();
  }

  setupPage(){
    this.userType = this.userService.currentUserType;
    this.setServiceType();
  }

  setServiceType(){
    this.serviceProviderService.getChosenOption().subscribe((option)=>{
      this.serviceType = option.id;
      //console.log(this.serviceType);
      this.getServiceProviders();
    });
  }

  getServiceProviders(){
    this.serviceProviders = [];
    this.yelpRatings = [];
    this.serviceProviderService.findServiceProviders(this.serviceType).subscribe((data: ServiceProvider[]) =>{
      this.serviceProviders = data;
      //console.log(this.serviceProviders);
      var i = 0;
      this.serviceProviders.forEach((serviceProvider)=>{
        this.serviceProviderService.getServiceProviderRatingsReviewCount(serviceProvider.name).subscribe((sp: ServiceProvider) =>{
          serviceProvider.rating = sp.rating;
          serviceProvider.review_count = sp.review_count;
          if(i == this.serviceProviders.length-1){
            for(let j = 0;j <= i; j++){
              this.yelpRatings[j] = {"name" : this.serviceProviders[j].name, "value" : this.serviceProviders[j].rating};
            }
            this.yelpRatings = [...this.yelpRatings];
            this.yelpRatingDataLoading = false;
            //console.log(this.yelpRatings);
          }
          i++;
        });     
      });
    });
  }

  scheduleAppointment(serviceProvider: string, service: string, serviceName: string){
    //console.log(serviceName);
    this.serviceProviderService.serviceProvider = serviceProvider;
    this.serviceProviderService.service = service;
    this.serviceProviderService.serviceName = serviceName;
    this.router.navigateByUrl('/schedule-appointment');
  }

  latitude=41.838902;
  longitude=-87.627472;
  circleRadius= 24140.2; // 15 miles
  zoom = 10;
  location(x){
    this.latitude=x.coords.lat;
    this.longitude=x.coords.lng;
  }

  icon = {
    url: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
    scaledSize: {
      width: 60,
      height: 60
    }
  }

}
