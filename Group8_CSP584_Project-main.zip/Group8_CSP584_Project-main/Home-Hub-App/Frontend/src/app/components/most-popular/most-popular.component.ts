import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-most-popular',
  templateUrl: './most-popular.component.html',
  styleUrls: ['./most-popular.component.css']
})
export class MostPopularComponent implements OnInit {

  @Input() mostPopularServices: any[];

  constructor(private userService: UsersService, private serviceProviderService: ServiceProvidersService, private router : Router) { }

  ngOnInit(): void {
  }

  scheduleAppointment(service: string, serviceProvider: string, serviceName: string){
    if(this.userService.currentUserType == "Customer"){
      //console.log(service, serviceProvider);
      this.serviceProviderService.serviceProvider = serviceProvider;
      this.serviceProviderService.service = service;
      this.serviceProviderService.serviceName = serviceName;
      this.router.navigateByUrl('/schedule-appointment');
    }
  }
}
