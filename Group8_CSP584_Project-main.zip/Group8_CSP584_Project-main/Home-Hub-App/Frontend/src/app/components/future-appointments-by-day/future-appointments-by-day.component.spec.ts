import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FutureAppointmentsByDayComponent } from './future-appointments-by-day.component';

describe('FutureAppointmentsByDayComponent', () => {
  let component: FutureAppointmentsByDayComponent;
  let fixture: ComponentFixture<FutureAppointmentsByDayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FutureAppointmentsByDayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FutureAppointmentsByDayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
