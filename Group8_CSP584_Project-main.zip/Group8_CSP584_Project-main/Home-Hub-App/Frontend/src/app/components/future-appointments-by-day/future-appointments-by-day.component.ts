import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { AppointmentsService } from 'src/app/appointments.service';
import { Appointment } from 'src/app/types/Appointment';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-future-appointments-by-day',
  templateUrl: './future-appointments-by-day.component.html',
  styleUrls: ['./future-appointments-by-day.component.css']
})
export class FutureAppointmentsByDayComponent implements OnInit {

  appointments: any[] = [];
  appointmentsByDay: any[] = [];
  data = [{"name": "Services Per Day", "series": []}];

  //used to determine if AM or PM should be used in string representing the starting or ending time
  ampm: string;

  //Used to display the chart data once it is loaded
  appointmentsByDayChartDataLoading: boolean;

  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { 
    this.appointmentsByDayChartDataLoading = true;
  }

  ngOnInit(): void {
    this.appointmentsService.getFutureServicesByDay(this.userService.currentUserName).subscribe((appointments: any[])=> {
      this.appointments = appointments;
      this.formatDateTime();
      this.getAppointmentsByDay();
    });
  }

  formatDateTime(){
    this.appointments.forEach((element)=> {
      element.dayServicePerformed = moment(element.dayServicePerformed).format('MM-DD-YYYY');
    });
  }

  displayedColumns: string[] = ['dayServicePerformed', 'numAppointments', 'totalCost'];

  getAppointmentsByDay(){
    for(let i=0;i<this.appointments.length;i++){
      this.appointmentsByDay[i] = {"name" : this.appointments[i].dayServicePerformed, "value" : this.appointments[i].numAppointments};
    }
    this.data = [{"name": "Services Per Day", "series": this.appointmentsByDay}];
    //console.log(this.data);
    this.appointmentsByDayChartDataLoading = false;
  }

}
