import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnregisterServiceComponent } from './unregister-service.component';

describe('UnregisterServiceComponent', () => {
  let component: UnregisterServiceComponent;
  let fixture: ComponentFixture<UnregisterServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnregisterServiceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UnregisterServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
