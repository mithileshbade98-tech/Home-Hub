import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Service } from 'src/app/types/Service';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-unregister-service',
  templateUrl: './unregister-service.component.html',
  styleUrls: ['./unregister-service.component.css']
})
export class UnregisterServiceComponent implements OnInit {

  currentServices: Service[];

  displayedColumns: string[] = ['service', 'costPerHour', 'removeService'];

  constructor(private serviceProviderService: ServiceProvidersService, private router: Router, private userService : UsersService) { }

  ngOnInit(): void {
    this.getCurrentServices();
  }

  getCurrentServices(){
    this.serviceProviderService.getCurrentServices(this.userService.currentUserName).subscribe((services: Service[])=> {
      this.currentServices = services;
      this.getServiceNames();
    });
  }

  getServiceNames(){
    var serviceOptions = this.serviceProviderService.getServices();
    for(let i=0; i<this.currentServices.length; i++){
      for(let j=0; j<serviceOptions.length; j++){
        if(this.currentServices[i].service == serviceOptions[j].id){
          this.currentServices[i].service = serviceOptions[j].name;
          break;
        }
      }
    }
  }

  removeService(service: string){
    var serviceOptions = this.serviceProviderService.getServices();
    for(let i=0; i<serviceOptions.length; i++){
      if(serviceOptions[i].name == service){
         service = serviceOptions[i].id;
        break;
      }
    }
    this.serviceProviderService.removeService(this.userService.currentUserName, service).subscribe((removed: boolean)=> {
      if(removed){
        this.getCurrentServices();
      }
    });

  }

}
