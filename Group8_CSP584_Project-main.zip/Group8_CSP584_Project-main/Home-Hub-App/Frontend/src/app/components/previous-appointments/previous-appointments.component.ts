import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { Appointment } from 'src/app/types/Appointment';
import { UsersService } from 'src/app/users.service';
import * as moment from 'moment';

@Component({
  selector: 'app-previous-appointments',
  templateUrl: './previous-appointments.component.html',
  styleUrls: ['./previous-appointments.component.css']
})
export class PreviousAppointmentsComponent implements OnInit {

  currentUserType: string;
  displayedColumns: string[];

  appointments: Appointment[];
  appointmentsByMonth: any[] = [];
  appointmentsByService: any[] = [];
  amountByMonth: any[] = [];
  //used to determine if AM or PM should be used in string representing the starting or ending time
  ampm: string;

  //Used to display the chart data once it is loaded
  appointmentsByMonthChartDataLoading: boolean;
  appointmentsByServiceChartDataLoading: boolean;
  amoountByMonthChartDataLoading: boolean;
  
  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { 
    this.appointmentsByMonthChartDataLoading = true;
    this.appointmentsByServiceChartDataLoading = true;
    this.amoountByMonthChartDataLoading = true;
  }

  ngOnInit(): void {
    this.currentUserType = this.userService.currentUserType
    this.setDisplayedColumns();
    this.appointmentsService.findPreviousAppointments(this.userService.currentUserName, this.currentUserType).subscribe((appointments: Appointment[])=> {
      this.appointments = appointments;
      this.formatDateTime();
      this.getAppointmentsByMonth();
      this.getPreviousAppointments();
      this.getCostPreviousServicesByMonth();
    });
  }

  setDisplayedColumns(){
    if(this.currentUserType == "Customer"){
      this.displayedColumns = ['serviceProvider', 'dayServicePerformed', 'service', 'serviceStartTime', 'serviceEndTime', 
      'serviceCost', 'streetAddress', 'city', 'state', 'zipCode'];
    }
    else if(this.currentUserType == "Service Provider"){
      this.displayedColumns = ['customer', 'dayServicePerformed', 'service', 'serviceStartTime', 'serviceEndTime', 
      'serviceCost', 'streetAddress', 'city', 'state', 'zipCode'];
    }
  }

  formatDateTime(){
    this.appointments.forEach((element)=> {
      element.displayDayServicePerformed = moment(element.dayServicePerformed).format('MM-DD-YYYY');

      var time = element.serviceStartTime.toString().split(':',2);
      var hours = time[0];
      var minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceStartTime = hours + ":" + minutes + " " + this.ampm;

      time = element.serviceEndTime.toString().split(':',2);
      hours = time[0];
      minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceEndTime = hours + ":" + minutes + " " + this.ampm;
    }); 
  }

  getAppointmentsByMonth(){
    this.appointmentsService.getPreviousServicesReceivedByMonth(this.userService.currentUserName, this.userService.currentUserType).subscribe((servicesReceivedByMonth: any[]) =>{
      //console.log(servicesReceivedByMonth);
      for(let i=0;i<servicesReceivedByMonth.length;i++){
        this.appointmentsByMonth[i] = {"name" : servicesReceivedByMonth[i].month.toString()+"/"+servicesReceivedByMonth[i].year.toString(), "value" : servicesReceivedByMonth[i].numServices};
      }
      this.appointmentsByMonthChartDataLoading = false;
    });
  }

  getPreviousAppointments(){
    this.appointmentsService.getPreviousServicesReceived(this.userService.currentUserName, this.userService.currentUserType).subscribe((servicesReceived: any[]) =>{
      //console.log(servicesReceived);
      for(let i=0;i<servicesReceived.length;i++){
        this.appointmentsByService[i] = {"name" : servicesReceived[i].serviceName, "value" : servicesReceived[i].numServices};
      }
      this.appointmentsByServiceChartDataLoading = false;
    });
  }

  getCostPreviousServicesByMonth(){
    this.appointmentsService.getAmountPaidForPreviousServicesByMonth(this.userService.currentUserName, this.userService.currentUserType).subscribe((costServicesReceivedByMonth: any[]) =>{
      //console.log(costServicesReceivedByMonth);
      for(let i=0;i<costServicesReceivedByMonth.length;i++){
        this.amountByMonth[i] = {"name" : costServicesReceivedByMonth[i].month.toString()+"/"+costServicesReceivedByMonth[i].year.toString(), "value" : parseFloat(costServicesReceivedByMonth[i].costServices.toString().substring(1).replace(',',''))};
      }
      this.amoountByMonthChartDataLoading = false;
    });
  }

}
