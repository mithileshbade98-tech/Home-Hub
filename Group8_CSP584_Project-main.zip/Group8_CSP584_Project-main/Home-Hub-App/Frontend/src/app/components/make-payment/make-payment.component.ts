import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { Appointment } from 'src/app/types/Appointment';
import { UsersService } from 'src/app/users.service';
import * as moment from 'moment';
import { Time } from '@angular/common';

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.css']
})
export class MakePaymentComponent implements OnInit {

  appointments: Appointment[];
  //used to determine if AM or PM should be used in string representing the starting or ending time
  ampm: string;

  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { }

  ngOnInit(): void {
    this.appointmentsService.findPreviousAppointments(this.userService.currentUserName, this.userService.currentUserType).subscribe((appointments: Appointment[])=> {
      this.appointments = appointments;
      this.formatDateTime();
    });
  }

  formatDateTime(){
    //If amount due for an appointment is zero, remove it from array of previous appointments
    for(let i = 0; i < this.appointments.length; i++){
      if(this.appointments[i].amountDue.toString() == '$0.00'){
        this.appointments.splice(i, 1);
      }
    }
    this.appointments.forEach((element)=> {
      element.displayDayServicePerformed = moment(element.dayServicePerformed).format('MM-DD-YYYY');

      var time = element.serviceStartTime.toString().split(':',2);
      var hours = time[0];
      var minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceStartTime = hours + ":" + minutes + " " + this.ampm;

      time = element.serviceEndTime.toString().split(':',2);
      hours = time[0];
      minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceEndTime = hours + ":" + minutes + " " + this.ampm;
    });


        
    
  }

  displayedColumns: string[] = ['serviceProvider', 'dayServicePerformed', 'service', 'serviceStartTime', 'serviceEndTime', 
  'serviceCost', 'amountDue', 'streetAddress', 'city', 'state', 'zipCode', 'makePayment'];

  makePayment(serviceProvider: string, startTime: Time, dayServicePerformed: Date, amountDue: number){
    this.appointmentsService.serviceProvider = serviceProvider;
    this.appointmentsService.startTime = startTime;
    this.appointmentsService.dayServicePerformed = dayServicePerformed;
    this.appointmentsService.amountDue = amountDue;
    this.router.navigateByUrl('/payment-info');
  }
  


}
