import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})
export class LineChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Input() data: any[];
  view: any[] = [400,400];
  gradient: boolean = false;
  xAxis: boolean = true;
  yAxis: boolean = true;
  legend: boolean = true;
  showXAxisLabel: boolean = true;
  showYAxisLabel: boolean = true;
  @Input() xAxisLabel: string;
  @Input() yAxisLabel: string;
  @Input() legendTitle: string;
  legendPosition: string = "below";
  animations: boolean = true;
  showGridLines: boolean = true;
  showDataLabel: boolean = true;
  tooltipDisabled: boolean = false;
  
}
