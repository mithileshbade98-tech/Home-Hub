import { Component, Directive, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { AppointmentsService } from 'src/app/appointments.service';
import { UsersService } from 'src/app/users.service';
import { Appointment } from 'src/app/types/Appointment';
import { Time } from '@angular/common';
import * as moment from 'moment';


@Component({
  selector: 'app-manage-appointments',
  templateUrl: './manage-appointments.component.html',
  styleUrls: ['./manage-appointments.component.css']
})

export class ManageAppointmentsComponent implements OnInit {

  appointments: Appointment[];
  appointmentsByMonth: any[] = [];
  appointmentsByService: any[] = [];
  amountByMonth: any[] = [];

  //used to determine if AM or PM should be used in string representing the starting or ending time
  ampm: string;

  //Used to display the chart data once it is loaded
  appointmentsByMonthChartDataLoading: boolean;
  appointmentsByServiceChartDataLoading: boolean;
  amoountByMonthChartDataLoading: boolean;

  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { 
    this.appointmentsByMonthChartDataLoading = true;
    this.appointmentsByServiceChartDataLoading = true;
    this.amoountByMonthChartDataLoading = true;
  }

  ngOnInit(): void {
    this.appointmentsService.findFutureAppointments(this.userService.currentUserName, this.userService.currentUserType).subscribe((appointments: Appointment[])=> {
      this.appointments = appointments;
      this.formatDateTime();
      this.getAppointmentsByMonth();
      this.getFutureAppointments();
      this.getCostFutureServicesByMonth();
    });
  }

  formatDateTime(){
    this.appointments.forEach((element)=> {
      element.displayDayServicePerformed = moment(element.dayServicePerformed).format('MM-DD-YYYY');

      var time = element.serviceStartTime.toString().split(':',2);
      var hours = time[0];
      var minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceStartTime = hours + ":" + minutes + " " + this.ampm;

      time = element.serviceEndTime.toString().split(':',2);
      hours = time[0];
      minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceEndTime = hours + ":" + minutes + " " + this.ampm;
    });


        
    
  }

  displayedColumns: string[] = ['serviceProvider', 'dayServicePerformed', 'service', 'serviceStartTime', 'serviceEndTime', 
  'serviceCost', 'streetAddress', 'city', 'state', 'zipCode', 'cancelAppointment', 'changeAppointment'];

  //Appointment is canceled and updated list of appointments pulled from postgreSQL
  public cancelAppointment(serviceProvider: string, startTime: Time, dayServicePerformed: Date){
    this.appointmentsService.cancelAppointment(this.userService.currentUserName, serviceProvider, startTime, dayServicePerformed).subscribe((deleted: boolean)=> {
      this.appointmentsService.findFutureAppointments(this.userService.currentUserName, this.userService.currentUserType).subscribe((appointments: Appointment[])=> {
        this.appointments = appointments;
        this.formatDateTime();
        this.getAppointmentsByMonth();
        this.getFutureAppointments();
        this.getCostFutureServicesByMonth();
      });
    });
  }

  public rescheduleAppointment(serviceProvider: string, startTime: Time, endTime: Time, dayServicePerformed: Date, service: string){
    this.appointmentsService.serviceProvider = serviceProvider;
    this.appointmentsService.startTime = startTime;
    this.appointmentsService.endTime = endTime;
    this.appointmentsService.dayServicePerformed = dayServicePerformed;
    this.appointmentsService.service = service;
    this.router.navigateByUrl('/reschedule-appointment');
  }

  getAppointmentsByMonth(){
    this.appointmentsService.getFutureServicesReceivedByMonth(this.userService.currentUserName, this.userService.currentUserType).subscribe((servicesReceivedByMonth: any[]) =>{
      //console.log(servicesReceivedByMonth);
      for(let i=0;i<servicesReceivedByMonth.length;i++){
        this.appointmentsByMonth[i] = {"name" : servicesReceivedByMonth[i].month.toString()+"/"+servicesReceivedByMonth[i].year.toString(), "value" : servicesReceivedByMonth[i].numServices};
      }
      this.appointmentsByMonth = [...this.appointmentsByMonth];
      this.appointmentsByMonthChartDataLoading = false;
    });
  }

  getFutureAppointments(){
    this.appointmentsService.getFutureServicesReceived(this.userService.currentUserName, this.userService.currentUserType).subscribe((servicesReceived: any[]) =>{
      //console.log(servicesReceived);
      for(let i=0;i<servicesReceived.length;i++){
        this.appointmentsByService[i] = {"name" : servicesReceived[i].serviceName, "value" : servicesReceived[i].numServices};
      }
      this.appointmentsByService = [...this.appointmentsByService];
      this.appointmentsByServiceChartDataLoading = false;
    });
  }

  getCostFutureServicesByMonth(){
    this.appointmentsService.getAmountPaidForFutureServicesByMonth(this.userService.currentUserName, this.userService.currentUserType).subscribe((costServicesReceivedByMonth: any[]) =>{
      //console.log(costServicesReceivedByMonth);
      for(let i=0;i<costServicesReceivedByMonth.length;i++){
        this.amountByMonth[i] = {"name" : costServicesReceivedByMonth[i].month.toString()+"/"+costServicesReceivedByMonth[i].year.toString(), "value" : parseFloat(costServicesReceivedByMonth[i].costServices.toString().substring(1).replace(',',''))};
      }
      this.amountByMonth = [...this.amountByMonth];
      this.amoountByMonthChartDataLoading = false;
    });
  }


}
