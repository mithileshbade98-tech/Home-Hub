import { Component, OnInit } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { EXTERIOR_OPTIONS } from 'src/app/exterior-options';
import { INTERIOR_OPTIONS } from 'src/app/interior-options';
import { LAWN_GARDEN_OPTIONS } from 'src/app/lawn-garden-options';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { UsersService } from 'src/app/users.service';
import { Option } from '../../types/Option';

@Component({
  selector: 'app-register-service',
  templateUrl: './register-service.component.html',
  styleUrls: ['./register-service.component.css']
})
export class RegisterServiceComponent implements OnInit {
  myControl = new FormControl('');
  interiorOptions = INTERIOR_OPTIONS;
  exteriorOptions = EXTERIOR_OPTIONS;
  lawnGardenOptions = LAWN_GARDEN_OPTIONS;

  services: Option[] = [];

  options: Option[] = [];
  optionNames: string[] = [];
  filteredOptions: Observable<string[]>;
  chosenOption: Option;
  costPerHourInvalid: boolean = false;
  
  constructor(private serviceProviderService: ServiceProvidersService, private router: Router, private userService : UsersService) { }

  ngOnInit(): void {
    var j = 0;
    for(let i = 0; i<this.interiorOptions.length; i++){
      this.options[j] = this.interiorOptions[i];
      j += 1;
    }
    for(let i = 0; i<this.exteriorOptions.length; i++){
      this.options[j] =this.exteriorOptions[i];
      j += 1;
    }
    for(let i = 0; i<this.lawnGardenOptions.length; i++){
      this.options[j] =this.lawnGardenOptions[i];
      j += 1;
    }

    for(let i = 0; i<this.options.length; i++){
      this.optionNames[i] = this.options[i].name;
    }

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
  }

  
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.optionNames.filter(optionNames=> optionNames.toLowerCase().startsWith(filterValue));
  }

  onClickSubmit(form: NgForm){
    this.costPerHourInvalid = false;
    
    if(isNaN(form.value.costPerHour)){
      this.costPerHourInvalid = true;
    } 

    if(!this.costPerHourInvalid){
      this.chosenOption = null;
      for(let i=0; i<this.options.length; i++){
        if(form.value.serviceName == this.options[i].name){
          this.chosenOption = this.options[i];
          break;
        }
      }
      
      this.serviceProviderService.addService(this.userService.currentUserName, this.chosenOption.id, form.value.costPerHour).subscribe((added: boolean)=> {
        if(added){
          this.router.navigateByUrl('/home-page');
          alert("Service Added");
        }
      });
    }
  }
  
}
