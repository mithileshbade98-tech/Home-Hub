import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RespondToReviewsComponent } from './respond-to-reviews.component';

describe('RespondToReviewsComponent', () => {
  let component: RespondToReviewsComponent;
  let fixture: ComponentFixture<RespondToReviewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RespondToReviewsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RespondToReviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
