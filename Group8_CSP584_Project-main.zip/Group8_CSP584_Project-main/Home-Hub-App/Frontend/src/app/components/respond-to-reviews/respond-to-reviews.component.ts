import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Review } from 'src/app/types/Review';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-respond-to-reviews',
  templateUrl: './respond-to-reviews.component.html',
  styleUrls: ['./respond-to-reviews.component.css']
})
export class RespondToReviewsComponent implements OnInit {

  //Review being responded to
  review: Review;

  constructor(private serviceProviderService: ServiceProvidersService, private userService: UsersService,  private router : Router) { }

  ngOnInit(): void {
    this.review = this.serviceProviderService.reviewToRespondTo;
  }

  onClickSubmit(form: NgForm){
    //console.log(form.value.response);
    this.serviceProviderService.addReviewResponse(this.review._id, form.value.response).subscribe((result: any) =>{
      if(result != false){
        this.router.navigateByUrl('/home-page');
        alert("Response Added");
      }
    });
  }



  

}
