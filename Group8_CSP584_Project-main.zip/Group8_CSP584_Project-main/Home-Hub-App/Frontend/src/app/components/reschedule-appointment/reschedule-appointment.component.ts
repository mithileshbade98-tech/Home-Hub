import { Time } from '@angular/common';
import { Component, OnInit, ɵisBoundToModule } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { UsersService } from 'src/app/users.service';
import * as moment from 'moment/moment';
import { Appointment } from 'src/app/types/Appointment';

@Component({
  selector: 'app-reschedule-appointment',
  templateUrl: './reschedule-appointment.component.html',
  styleUrls: ['./reschedule-appointment.component.css']
})
export class RescheduleAppointmentComponent implements OnInit {
  
  service: string;
  serviceProvider: string;
  startTime: Time;
  endTime: Time;
  dayServicePerformed: Date;
  costPerHour: number;
  totalCost: number;
  overlappingAppointments: Appointment[];
  
  //Variables used to find the appointment being updated in PostgreSQL to update it
  oldStartTime: Time;
  oldDayServicePerformed: Date;

  editable: boolean = true;
  
  //Boolean that indicates if there is already an appointment at the time the user is trying to set the appointment to
  overlappingAppointment: boolean = false;

  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { 
  }

  ngOnInit(): void {
    this.setAppointmentInfo();
  }

  setAppointmentInfo(){
    this.service = this.appointmentsService.service;
    this.serviceProvider = this.appointmentsService.serviceProvider;
    this.startTime = this.appointmentsService.startTime;
    this.endTime = this.appointmentsService.endTime;
    this.dayServicePerformed = this.appointmentsService.dayServicePerformed;
    this.oldStartTime = this.startTime;
    this.oldDayServicePerformed = this.dayServicePerformed;
    this.appointmentsService.getServiceCost(this.serviceProvider, this.service).subscribe((cost: number)=> {
      this.costPerHour = cost;
    });
  }

  public onClickSubmit(form: NgForm) {
    this.startTime = form.value.startTime; 
    this.endTime = form.value.endTime;
    this.totalCost = this.getNumberHours() * +(this.costPerHour.toString().substring(1));
    this.dayServicePerformed = form.value.dayServicePerformed;

    this.appointmentsService.getAppointmentsByDateTime(this.dayServicePerformed, this.serviceProvider, this.startTime, this.endTime).subscribe((appointments: Appointment[]) => {
      this.overlappingAppointments = appointments;
      var index = 0;
      this.overlappingAppointments.forEach(appointment => {
        if(appointment.serviceStartTime == this.oldStartTime){
          this.overlappingAppointments.splice(index, 1);
        }
        index++;
      });

      if(appointments.length == 0){
        this.appointmentsService.updateAppointment(this.oldStartTime, moment(this.oldDayServicePerformed).format('YYYY-MM-DD'), this.startTime, this.endTime, moment(this.dayServicePerformed).format("YYYY-MM-DD"), this.serviceProvider, this.userService.currentUserName, this.totalCost).subscribe((updated: boolean)=> {
          if(updated){
            this.router.navigateByUrl('/home-page');
            alert("Appointment Updated");
          }
        });
      }else{
        this.overlappingAppointment = true;
      }
    });
  }

  getNumberHours(){
    var time = this.startTime.toString().split(':',2);
    var hours = +time[0];
    var minutes = +time[1];
    var totalMinStartTime = hours * 60 + minutes;
    
    var time = this.endTime.toString().split(':',2);
    var hours = +time[0];
    var minutes = +time[1];
    var totalMinEndTime = hours * 60 + minutes;

    return ((totalMinEndTime - totalMinStartTime)/60);
    
  } 
}


