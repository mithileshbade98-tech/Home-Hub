import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Review } from 'src/app/types/Review';
import { Service } from 'src/app/types/Service';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-view-reviews',
  templateUrl: './view-reviews.component.html',
  styleUrls: ['./view-reviews.component.css']
})
export class ViewReviewsComponent implements OnInit {

  searchTypeUndefined: boolean = false;
  searchCriteriaUndefined: boolean = false;
  reviewsReceived: boolean = false;

  searchType: string;
  searchTypes: string[] = ["Search by Service Type", "Search by Service Provider Name"];

  searchCriteria: string;
  possibleSearchCriteria: string[] = [];

  reviews: Review[];

  username: string;
  usertype: string;
  usernames: string[] = [];

  displayedColumns: string[] = [];

  constructor(private serviceProviderService: ServiceProvidersService, private userService: UsersService, private router : Router) { }

  ngOnInit(): void {
    this.username = this.userService.currentUserName;
    this.usertype = this.userService.currentUserType;
    if(this.usertype == "Service Provider"){
      this.displayedColumns = ['customer', 'serviceProvider', 'date', 'service', 'rating', 'review_text', 'response','addUpdateResponse'];
    }
    else{
      this.displayedColumns = ['customer', 'serviceProvider', 'date', 'service', 'rating', 'review_text', 'response'];
    }
  }

  changeSearchType(value: string){
    this.possibleSearchCriteria = [];
    this.searchType = value;
    //console.log(value);
    if(value == "Search by Service Type"){
      this.serviceProviderService.findAllServices().subscribe((services: string[]) => {
        this.possibleSearchCriteria = services;
      });
    }
    else if(value == "Search by Service Provider Name"){
      this.serviceProviderService.findAllServiceProviders().subscribe((serviceProviders: string[]) => {
        this.possibleSearchCriteria = serviceProviders;
      });
    }
  }

  changeSearchCriteria(value: string){
    this.searchCriteria = value;
  }

  public onClickSubmit(form: NgForm) {
    this.searchTypeUndefined = false;
    this.searchCriteriaUndefined = false;

    if(this.searchType == null){
      this.searchTypeUndefined = true;
    }
    if(this.searchCriteria == null){
      this.searchCriteriaUndefined = true;
    }

    if(!this.searchTypeUndefined && !this.searchCriteriaUndefined){
      this.reviews = []
      if(this.searchType == "Search by Service Type"){
        //Save service name to be used when presenting reviews
        var servicename = this.searchCriteria;
        this.serviceProviderService.getServiceId(this.searchCriteria).subscribe((serviceid: string) =>{
          this.serviceProviderService.findReviewsByServiceType(serviceid).subscribe((reviews: Review[]) =>{
            this.reviews = reviews;
            //Display service name instead of service id in reviews
            this.reviews.forEach(function (review, i) {
              review.service = servicename;
            });
            this.formatDateTime();
            this.setUsernamesArray();
            this.reviewsReceived = true;
          });
        });
      }else if(this.searchType == "Search by Service Provider Name"){
        this.serviceProviderService.findReviewsByServiceProviderName(this.searchCriteria).subscribe((reviews: Review[]) =>{
          this.reviews = reviews;
          this.serviceProviderService.findAllServiceIDs().subscribe((services: Service[]) =>{
            //Display service name instead of service id in reviews
            this.reviews.forEach(function (review, i) {
              for(let i=0;i<services.length;i++){
                if(services[i].service == review.service){
                  review.service = services[i].serviceName;
                }
              }
            });
            this.formatDateTime();
            this.setUsernamesArray();
            this.reviewsReceived = true;
          });
        });
      }
    }
  }

  formatDateTime(){
    this.reviews.forEach((element)=> {
      element.date = moment(element.date).format('MM-DD-YYYY');
    });
  }

  //Sets username array to determine if input should be shown for service provider to respond to a review
  setUsernamesArray(){
    for(let i=0;i<this.reviews.length;i++){
      this.usernames[i] = this.reviews[i].service_provider;
    }
  }

  addUpdateResponse(index: number){
    var review = this.reviews[index];
    //console.log(review);
    this.serviceProviderService.reviewToRespondTo = review;
    this.router.navigateByUrl('/respond-to-reviews');
  }

}
