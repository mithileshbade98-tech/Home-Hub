import { Component, OnInit } from '@angular/core';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { ServiceProvider } from 'src/app/types/User';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  constructor(private serviceProviderService: ServiceProvidersService, private userService : UsersService) { 
    this.mostPopularServiceDataLoading = true;
  }

  mostPopularServices: any[];
  mostPopularServiceDataLoading: boolean;

  userType: string = null;

  ngOnInit(): void {
    this.setUserType();
  }

  setUserType(){
    this.userType = this.userService.currentUserType;
    this.userService.getUserType().subscribe((type)=>{
      if(type != null){
        this.userType = type;
      }
      //console.log(type);
      this.getMostPopularServices();
    });
    //console.log(this.userType);
  }

  getMostPopularServices(){
    this.serviceProviderService.getMostPopularServices().subscribe((mostPopularServices: ServiceProvider[]) =>{
      //console.log(mostPopularServices);
      this.mostPopularServices = mostPopularServices;
      var index = 0;
      this.mostPopularServices.forEach((serviceProvider)=>{
        this.serviceProviderService.getServiceProviderRatingsReviewCount(serviceProvider.serviceProvider).subscribe((sp: ServiceProvider) =>{
          serviceProvider.rating = sp.rating;
          serviceProvider.review_count = sp.review_count;
          index++;
          if(index == 4){
            this.mostPopularServiceDataLoading = false;
          }
        });     
      });
    });
  }
}
