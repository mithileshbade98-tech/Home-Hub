import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  @Input() data: any[];
  view: any[] = [500,400];
  schemeType: string = 'ordinal';
  gradient: boolean = false;
  xAxis: boolean = true;
  yAxis: boolean = true;
  legend: boolean = true;
  showXAxisLabel: boolean = true;
  showYAxisLabel: boolean = true;
  @Input() xAxisLabel: string;
  @Input() yAxisLabel: string;
  @Input() legendTitle: string;
  legendPosition: string = "below";
  animations: boolean = true;
  showGridLines: boolean = true;
  showDataLabel: boolean = true;
  barPadding: number = 5;
  tooltipDisabled: boolean = false;
  roundEdges: boolean = false;

  /*@Input() addDollarSignToYAxisLabels: string;
  yAxisTickFormatting(value){
    if(this.addDollarSignToYAxisLabels == "true"){
      return '$' + value;
    }
    return value;
  }*/

  constructor() { }

  ngOnInit(): void {
  }

}
