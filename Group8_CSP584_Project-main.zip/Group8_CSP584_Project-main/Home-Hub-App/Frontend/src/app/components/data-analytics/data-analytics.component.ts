import { Component, OnInit } from '@angular/core';
import { ServiceProvidersService } from 'src/app/service-providers.service';

@Component({
  selector: 'app-data-analytics',
  templateUrl: './data-analytics.component.html',
  styleUrls: ['./data-analytics.component.css']
})
export class DataAnalyticsComponent implements OnInit {

  servicesMostAppointmentsReceived: boolean;
  servicesMostAppointments: any[] = [];
  quantityServices: any[] = []; //Modification of servicesMostAppointments array to show data in chart

  highestRatedServiceProvidersReceived: boolean;
  highestRatedServiceProviders: any[] = [];
  serviceProviders: any[] = [];   //Modification of highestRatedServiceProviders array to show data in chart

  serviceRevenueReceived: boolean;
  serviceRevenueByService: any[] = [];
  serviceRevenue: any[] = []; //Modification of serviceRevenueByService array to show data in chart


  displayedServicesMostAppointmentsColumns: string[] = ['service', 'numServices'];
  displayedHighestRatedServiceProvidersColumns: string[] = ['serviceProvider', 'rating'];
  displayedServiceRevenueByServiceColumns: string[] = ['service', 'revenue'];


  constructor(private serviceProviderService : ServiceProvidersService) { }

  ngOnInit(): void {
    this.getNumberServicesProvided();
    this.getHighestRateServiceProviders();
    this.getServiceRevenue();
  }

  getNumberServicesProvided() {
    this.serviceProviderService.getNumberServicesProvided().subscribe((quantityServices: any[]) =>{
      this.servicesMostAppointments = quantityServices;
      for(let i=0;i<quantityServices.length;i++){
        this.quantityServices[i] = {"name" : quantityServices[i].serviceName, "value" : parseInt(quantityServices[i].numServices)};
      }
      this.servicesMostAppointmentsReceived = true;
    });
  }

  getHighestRateServiceProviders() {
    this.serviceProviderService.getHighestRatedServiceProviders().subscribe((serviceProviders: any[]) =>{
      //console.log(serviceProviders);
      this.highestRatedServiceProviders = serviceProviders;
      for(let i=0;i<serviceProviders.length;i++){
        this.serviceProviders[i] = {"name" : serviceProviders[i].name, "value" : parseInt(serviceProviders[i].rating)};
      }
      this.highestRatedServiceProvidersReceived = true;
    });
  }

  getServiceRevenue(){
    this.serviceProviderService.getServiceRevenue().subscribe((serviceRevenue: any[]) =>{
      //console.log(serviceRevenue);
      this.serviceRevenueByService = serviceRevenue;
      for(let i=0;i<serviceRevenue.length;i++){
        this.serviceRevenue[i] = {"name" : serviceRevenue[i].serviceName, "value" : parseFloat(serviceRevenue[i].serviceRevenue.toString().substring(1).replace(',',''))};
      }
      this.serviceRevenueReceived = true;
    });
  }
}
