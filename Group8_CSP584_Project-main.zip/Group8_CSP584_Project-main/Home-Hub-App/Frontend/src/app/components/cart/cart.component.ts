import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { Appointment } from 'src/app/types/Appointment';
import * as moment from 'moment';
import { Time } from '@angular/common';
import { UsersService } from 'src/app/users.service';
import { ServiceProvidersService } from 'src/app/service-providers.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems: Appointment[] = [];
  cartItem: Appointment;
  overlappingAppointments: Appointment[] = [];

  //used to determine if AM or PM should be used in string representing the starting or ending time
  ampm: string;

  noCartItems: boolean = true;

  done: boolean = false; //Determines if check can be done to see if all cart items were added to appointments table
  

  constructor(private appointmentsService : AppointmentsService, private router : Router, private userService : UsersService, private cdRef : ChangeDetectorRef, private serviceProviderService : ServiceProvidersService) { }

  displayedColumns: string[] = ['serviceProvider', 'service', 'dayServicePerformed', 'startTime', 'endTime', 'serviceCost', 'streetAddress', 'city', 'state', 'zipCode', 'removeItem'];

  ngOnInit(): void {
    this.getCartItems();
  }

  getCartItems(){
    this.appointmentsService.getCartItems().subscribe((cartItems: Appointment[]) =>{
      //console.log(cartItems);
      this.cartItems = cartItems;
      this.formatDateTime();
      if(this.cartItems.length > 0){
        this.noCartItems = false;
        this.cdRef.detectChanges();
      }
    });
  }

  formatDateTime(){
    this.cartItems.forEach((element)=> {
      element.displayDayServicePerformed = moment(element.dayServicePerformed).format('MM-DD-YYYY');
      //console.log(element.serviceStartTime);
      //console.log(element.serviceEndTime);
      var time = element.serviceStartTime.toString().split(':',2);
      var hours = time[0];
      var minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceStartTime = hours + ":" + minutes + " " + this.ampm;

      time = element.serviceEndTime.toString().split(':',2);
      hours = time[0];
      minutes = time[1];

      this.ampm = 'AM'
      if(parseInt(hours) == 12){
        this.ampm = 'PM';
      }
      if(parseInt(hours) > 12){
        hours = (parseInt(hours) - 12).toString();
        this.ampm = 'PM';
      }
      element.displayServiceEndTime = hours + ":" + minutes + " " + this.ampm;
    }); 
  }

  removeFromCart(serviceProvider: string, serviceStartTime: Time, dayServicePerformed: Date){
    this.appointmentsService.removeCartItem(serviceProvider, serviceStartTime, dayServicePerformed).subscribe((removed: boolean) =>{
      if(removed){
        this.appointmentsService.getCartItems().subscribe((cartItems: Appointment[]) =>{
          this.cartItems = cartItems;
          this.formatDateTime();
          if(this.cartItems.length == 0){
            this.noCartItems = true;
            this.cdRef.detectChanges();
          }
        });
      }
    });
  }

  onClickSubmit(){
    this.cartItems.forEach((cartItem)=>{
      this.appointmentsService.getAppointmentsByDateTime(cartItem.dayServicePerformed, cartItem.serviceProvider, cartItem.serviceStartTime, cartItem.serviceEndTime).subscribe((appointments: Appointment[]) => {
        this.overlappingAppointments = appointments;
        this.createAppointment(cartItem);
      });
    });
  }

  createAppointment(cartItem: Appointment){
    if(this.overlappingAppointments.length == 0){
      this.appointmentsService.createAppointment(cartItem, this.userService.currentUserName).subscribe((added: boolean) => {
        //console.log(added);
          if(added){
            this.appointmentsService.clearCart().subscribe((cleared: boolean) => {
              if(cleared){
                this.router.navigateByUrl('/home-page');
                alert("Appointments for "+ cartItem.serviceProvider +" at "+ cartItem.displayServiceStartTime +" Created");
              }
            });
          }else{
              alert("Appointment for "+ cartItem.serviceProvider +" at "+ cartItem.displayServiceStartTime +" Could Not be Created Because Service Provider Already has an Appointment at that Time. Please Try Again.");
          }
      });
    }else{
      alert("Appointment for "+ cartItem.serviceProvider +" at "+ cartItem.displayServiceStartTime +" Could Not be Created Because Service Provider Already has an Appointment at that Time. Please Try Again.");
    }
  }
}
