import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserType } from 'src/app/types/UserType';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userName: string;
  password: string;
  type: string;
  selectedType: string;
  typeSelected: boolean = true;
  streetAddress: string;
  city: string;
  state: string;
  zipCode: number;
  email: string;
  phoneNumber: number;
  zipCodeValid: boolean = true;
  phoneNumberValid: boolean = true;
  usernameValid: boolean = true;
  latitude: number;
  longitude: number;
  latitudeValid: boolean = true;
  longitudeValid: boolean = true;

  constructor(private userService : UsersService, private router : Router) { }

  ngOnInit() {}

  userTypes: UserType[] = [
    {value: "Customer", viewValue: "Customer"},
    {value: "Service Provider", viewValue: "Service Provider"}
  ]

  changeType(value: string){
    this.type = value;
  }

  public onClickSubmit(form: NgForm) {
    this.zipCodeValid = true;
    this.phoneNumberValid = true;
    this.latitudeValid = true;
    this.longitudeValid = true;
    this.typeSelected = true;
    this.userName = form.value.username;
    this.password = form.value.password;
    this.streetAddress = form.value.streetaddress;
    this.city = form.value.city;
    this.state = form.value.state;
    this.zipCode = form.value.zipcode;
    this.email = form.value.email;
    this.phoneNumber = form.value.phonenumber;
    this.latitude = form.value.latitude;
    this.longitude = form.value.longitude;

    if(form.value.zipcode=="" || isNaN(form.value.zipcode)){
      this.zipCodeValid = false;
    } 
    else{
      this.zipCode = parseInt(form.value.zipcode);
    }
    
    if(form.value.phonenumber=="" || isNaN(form.value.phonenumber)){
      this.phoneNumberValid = false;
    } 
    else{
      this.phoneNumber = parseInt(form.value.phonenumber);
    }

    if(form.value.latitude=="" || isNaN(form.value.latitude)){
      this.latitudeValid = false;
    } 
    else{
      this.latitude = parseFloat(form.value.latitude);
    }

    if(form.value.longitude=="" || isNaN(form.value.longitude)){
      this.longitudeValid = false;
    } 
    else{
      this.longitude = parseFloat(form.value.longitude);
    }

    if(this.type != "Customer" && this.type != "Service Provider"){
      this.typeSelected = false;
    }

    if(this.phoneNumberValid && this.zipCodeValid && this.usernameValid && this.latitudeValid && this.longitudeValid && this.userName != "" && this.password != "" && 
        this.streetAddress != "" && this.city != "" && this.state != "" && this.typeSelected){
      this.userService.addUser(this.userName, this.password, this.type, this.streetAddress, this.city, this.state, this.zipCode, this.email, this.phoneNumber).subscribe((added: boolean) => {
        if(added){
          this.userService.addUserLocation(this.type, this.userName, this.latitude, this.longitude).subscribe((added: boolean) => {
            if(added){
              this.router.navigateByUrl('/login');
            }
          });
        }
      });
    }
  }

  //Queries database to get count of users with the username provided by the user creating an account
  checkUsername(form: NgForm){
    this.userService.checkIfUserExists(form.value.username).subscribe((countOfUsers: number) => {
      if(countOfUsers == 1){
        this.usernameValid = false;
      }
      else if(countOfUsers == 0){
        this.usernameValid = true;
      }
    });
  }
}
