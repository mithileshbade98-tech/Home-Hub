import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-payment-info',
  templateUrl: './payment-info.component.html',
  styleUrls: ['./payment-info.component.css']
})
export class PaymentInfoComponent implements OnInit {

  cardValid: boolean = true;
  paymentAmountTooHigh: boolean = false;
  paymentAmountValid: boolean = true;
  editable: boolean = false;

  amountDue: number;
  customer: string;
  paymentAmount: number;
  cardNumber: number;

  constructor(private userService : UsersService, private appointmentsService : AppointmentsService, private router : Router) { }

  ngOnInit(): void {
    this.amountDue = this.appointmentsService.amountDue;
  }

  public onClickSubmit(form: NgForm) {
    //Reset booleans
    this.cardValid = true;
    this.paymentAmountTooHigh = false;
    this.paymentAmountValid = true;
    
    //Have to get rid of the $ on amountDue
    let ad = (this.appointmentsService.amountDue).toString().substring(1);
    this.amountDue = +ad;

    this.customer = this.userService.currentUserName;
    this.paymentAmount = +form.value.paymentAmount;
    this.cardNumber = +form.value.creditCard;

    if(this.paymentAmount > +this.amountDue){
      this.paymentAmountTooHigh = true;
    }
    if(isNaN(this.cardNumber) || !Number.isInteger(this.cardNumber)){
      this.cardValid = false;
    }
    if(isNaN(this.paymentAmount)){
      this.paymentAmountValid = false;
    }
    if(!this.paymentAmountTooHigh && this.cardValid && this.paymentAmountValid){
      this.amountDue = this.amountDue - this.paymentAmount;
      this.appointmentsService.makePayment(this.userService.currentUserName, this.amountDue).subscribe((updated: boolean) => {
        if(updated){
          this.router.navigateByUrl('/home-page');
          alert("Payment Successful");
        }
      });
    }

    
  }

}
