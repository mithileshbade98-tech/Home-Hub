import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionalVideosComponent } from './instructional-videos.component';

describe('InstructionalVideosComponent', () => {
  let component: InstructionalVideosComponent;
  let fixture: ComponentFixture<InstructionalVideosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstructionalVideosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstructionalVideosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
