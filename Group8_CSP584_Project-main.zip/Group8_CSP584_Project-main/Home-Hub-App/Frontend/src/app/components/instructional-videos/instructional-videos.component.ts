import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InstructionalVideo } from 'src/app/types/InstructionalVideo';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-instructional-videos',
  templateUrl: './instructional-videos.component.html',
  styleUrls: ['./instructional-videos.component.css']
})
export class InstructionalVideosComponent implements OnInit {

  videos: InstructionalVideo[];

  constructor(private userService : UsersService, private router: Router) { }

  ngOnInit(): void {
    this.getVideos();
  }

  getVideos(){
    this.videos = [];
    this.userService.getVideoIds(this.userService.chosenVideoType).subscribe((videos: InstructionalVideo[])=> {
      this.videos = videos;
    });
  }

}
