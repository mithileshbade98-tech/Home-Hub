import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Option } from '../../types/Option';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

  @Input() name: string;
  @Input() options: Option[];

  constructor(private serviceProviderService: ServiceProvidersService, private router : Router) {
  }

  ngOnInit(): void {
  }

  onClick(option: Option){
    this.serviceProviderService.setChosenOption(option);
    this.router.navigateByUrl('/list-of-service-providers');
  }

}
