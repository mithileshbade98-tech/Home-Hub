import { Component, Input, OnInit } from '@angular/core';
import { INTERIOR_OPTIONS } from 'src/app/interior-options';
import { EXTERIOR_OPTIONS } from 'src/app/exterior-options';
import { LAWN_GARDEN_OPTIONS } from 'src/app/lawn-garden-options';
import { DO_IT_YOURSELF } from 'src/app/do-it-yourself';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/users.service';
import { AppointmentsService } from 'src/app/appointments.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  title = 'Home Hub';
  interiorOptions = INTERIOR_OPTIONS;
  exteriorOptions = EXTERIOR_OPTIONS;
  lawnGardenOptions = LAWN_GARDEN_OPTIONS;
  doItYourself = DO_IT_YOURSELF;

  userType: string = null;

  constructor(private userService : UsersService, private appointmentsService: AppointmentsService, private router: Router) { }

  

  ngOnInit(): void {
    this.setUserType();
  }

  setUserType(){
    this.userType = this.userService.currentUserType;
    //console.log(this.userType);
  }

  userSignOut(){
    this.userType = "None";
    this.userService.currentUserType = "None";
    this.userService.setUserType("None");
    this.appointmentsService.clearCart().subscribe((cleared: boolean) => {
      if(cleared){
        console.log("Cart Cleared");
      }
    });
    this.router.navigateByUrl('/home-page');
  }

  chosenVideoCategory(type: string){
    this.userService.chosenVideoType = type;
    this.router.navigateByUrl('/instructional-videos');
  }


}
