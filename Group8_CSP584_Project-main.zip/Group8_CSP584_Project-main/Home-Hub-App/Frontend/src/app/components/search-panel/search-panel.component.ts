import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { INTERIOR_OPTIONS } from 'src/app/interior-options';
import { EXTERIOR_OPTIONS } from 'src/app/exterior-options';
import { LAWN_GARDEN_OPTIONS } from 'src/app/lawn-garden-options';
import { Option } from '../../types/Option';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';

@Component({
  selector: 'app-search-panel',
  templateUrl: './search-panel.component.html',
  styleUrls: ['./search-panel.component.css']
})
export class SearchPanelComponent implements OnInit {
  myControl = new FormControl('');
  interiorOptions = INTERIOR_OPTIONS;
  exteriorOptions = EXTERIOR_OPTIONS;
  lawnGardenOptions = LAWN_GARDEN_OPTIONS;
  
  options: Option[] = [];
  optionNames: string[] = [];
  filteredOptions: Observable<string[]>;
  chosenOption: Option;
  
  constructor(private serviceProviderService: ServiceProvidersService, private router: Router) { }
  

  ngOnInit(): void {
    this.options = this.serviceProviderService.getServices();

    for(let i = 0; i<this.options.length; i++){
      this.optionNames[i] = this.options[i].name;
    }

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.optionNames.filter(optionNames=> optionNames.toLowerCase().startsWith(filterValue));
  }

  onClick(optionName: string){
    this.chosenOption = null;
    for(let i=0; i<this.options.length; i++){
      if(optionName == this.options[i].name){
        this.chosenOption = this.options[i];
        break;
      }
    }
    this.serviceProviderService.chosenOption = this.chosenOption;
    this.router.navigateByUrl('/list-of-service-providers');
  }

}

