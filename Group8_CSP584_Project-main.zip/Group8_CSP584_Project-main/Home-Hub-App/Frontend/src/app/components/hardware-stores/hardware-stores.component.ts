import { Component, OnInit } from '@angular/core';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { HardwareStore } from 'src/app/types/HardwareStore';

@Component({
  selector: 'app-hardware-stores',
  templateUrl: './hardware-stores.component.html',
  styleUrls: ['./hardware-stores.component.css']
})
export class HardwareStoresComponent implements OnInit {

  constructor(private serviceProviderService: ServiceProvidersService) { }

  hardwareStores: HardwareStore[] = [];

  displayedColumns: string[] = ['storeName', 'streetAddress', 'city', 'state', 'zipCode', 'rating', 'numberOfReviews'];

  latitude=41.838902;
  longitude=-87.627472;
  circleRadius= 8046.72; // 5 miles
  zoom = 11;
  location(x){
    this.latitude=x.coords.lat;
    this.longitude=x.coords.lng;
  }

  icon = {
    url: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
    scaledSize: {
      width: 60,
      height: 60
    }
  }

  ngOnInit(): void {
    this.getHardwareStores();
  }

  getHardwareStores(){
    this.serviceProviderService.getHardwareStores().subscribe((stores: HardwareStore[]) =>{
      this.hardwareStores = stores;
      //console.log(this.hardwareStores);
      for(let i = 0;i < this.hardwareStores.length; i++){
        this.serviceProviderService.getServiceProviderRatingsReviewCount(this.hardwareStores[i].storeName).subscribe((store: HardwareStore) =>{
          this.hardwareStores[i].rating = store.rating;
          this.hardwareStores[i].review_count = store.review_count;
        });    
      }
    });
  }

}
