import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { UsersService } from 'src/app/users.service';
import * as moment from 'moment';
import { AppointmentsService } from 'src/app/appointments.service';
import {  User } from 'src/app/types/User';

@Component({
  selector: 'app-schedule-appointment',
  templateUrl: './schedule-appointment.component.html',
  styleUrls: ['./schedule-appointment.component.css']
})
export class ScheduleAppointmentComponent implements OnInit {

  serviceProvider: string;
  service: string;
  serviceName: string;
  startTime: Time;
  endTime: Time;
  dayServicePerformed: Date;
  cost: number;
  userCity: string;
  userState: string;
  userZipCode: number;
  userStreetAddress: string;

  currentDate: Date;
  appointmentStartDate: Date;
  appointmentEndDate: Date;

  editable: boolean = false;

  invalidStartDate: boolean = false;
  invalidEndDate: boolean = false;


  constructor(private userService : UsersService, private serviceProviderService: ServiceProvidersService, private router : Router, private appointmentsService : AppointmentsService) { }

  ngOnInit(): void {
    this.serviceProvider = this.serviceProviderService.serviceProvider;
    this.service = this.serviceProviderService.service;
    this.serviceName = this.serviceProviderService.serviceName;
  }

  onClickSubmit(form: NgForm){
    //Resetting booleans that control the error messages
    this.invalidStartDate = false;
    this.invalidEndDate = false;

    this.startTime = form.value.startTime;
    this.endTime = form.value.endTime;
    this.dayServicePerformed = form.value.dayServicePerformed;
    
    this.getCurrentTime();
    
    if(this.appointmentStartDate < this.currentDate){
      this.invalidStartDate = true;
    }
    if(this.appointmentEndDate < this.appointmentStartDate){
      this.invalidEndDate = true;
    }

    if(!this.invalidEndDate && !this.invalidStartDate){
      this.appointmentsService.getServiceCost(this.serviceProvider, this.service).subscribe((serviceCost: string)=> {
        this.cost = this.getServiceCost(+serviceCost.substring(1));
        
        this.userService.getUserAddress(this.userService.currentUserName).subscribe((userAddress: User) => {
          this.userCity = userAddress.city;
          this.userState = userAddress.state;
          this.userZipCode = userAddress.zipCode;
          this.userStreetAddress = userAddress.streetAddress;

          this.appointmentsService.addAppointmentToCart(moment(this.dayServicePerformed).format('YYYY-MM-DD'), this.startTime, this.endTime, this.serviceProvider, this.cost, 
            this.service, this.userStreetAddress, this.userCity, this.userState, this.userZipCode).subscribe((added: boolean)=> {
  
            if(added){
              this.router.navigateByUrl('/home-page');
              alert("Appointment Added to Cart");
            }
          });
        });
      });
    }
  }

  getCurrentTime(){
    this.currentDate = new Date();

    var time = this.startTime.toString().split(':',2);
    var hours = +time[0];
    var minutes = +time[1];

    this.appointmentStartDate = new Date(this.dayServicePerformed.getFullYear(), this.dayServicePerformed.getMonth(), this.dayServicePerformed.getDate(), hours, minutes );
    

    var time = this.endTime.toString().split(':',2);
    var hours = +time[0];
    var minutes = +time[1];

    this.appointmentEndDate = new Date(this.dayServicePerformed.getFullYear(), this.dayServicePerformed.getMonth(), this.dayServicePerformed.getDate(), hours, minutes );
    
  } 

  getServiceCost(serviceCost: number){
      //Calculating the total cost of service
      const msInHour = 1000 * 60 * 60;

      return parseFloat((((this.appointmentEndDate.getTime() - this.appointmentStartDate.getTime()) / msInHour) * serviceCost).toFixed(2));
  }
}
