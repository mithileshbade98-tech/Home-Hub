import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Review } from 'src/app/types/Review';
import { Service } from 'src/app/types/Service';
import { ServiceProvider, User } from 'src/app/types/User';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-write-review',
  templateUrl: './write-review.component.html',
  styleUrls: ['./write-review.component.css']
})
export class WriteReviewComponent implements OnInit {

  serviceProvider: string;
  service: string;
  serviceProviders: ServiceProvider[];
  serviceProviderNames: string[] = [];
  services: Service[] = [];
  rating: number;
  reviewText: string;

  //Booleans to determine the message that appears on the review form if there is an error
  serviceProviderUndefined:boolean = false;
  serviceUndefined:boolean = false;
  ratingUndefined:boolean = false;
  reviewTextUndefined:boolean = false;

  constructor(private serviceProviderService: ServiceProvidersService, private router : Router, private userService : UsersService) { }

  ngOnInit(): void { 
    this.serviceProviderService.findPreviousServiceProviders(this.userService.currentUserName).subscribe((sp: ServiceProvider[]) =>{
      this.serviceProviders = sp;
      for(let i = 0; i < sp.length; i++){
        if(!this.serviceProviderNames.includes(sp[i].name)){
          this.serviceProviderNames.push(sp[i].name);
        }
      }
    });
  }

  changeServiceProvider(value: string){
    this.serviceProvider = value;
    this.getServices();
  }

  changeService(value: string){
    this.service = value;
  }

  public changeRating(value: number) {
    this.rating = value;
  }

  public onClickSubmit(form: NgForm) {
    //Reset booleans
    this.serviceProviderUndefined = false;
    this.serviceUndefined = false;
    this.ratingUndefined = false;
    this.reviewTextUndefined = false;

    if(this.serviceProvider == null){
      this.serviceProviderUndefined = true;
    }
    if(this.service == null){
      this.serviceUndefined = true;
    }
    if(this.rating == null){
      this.ratingUndefined = true;
    }
    if(form.value.reviewText == null){
      this.reviewTextUndefined = true;
    }
    
    this.reviewText = form.value.reviewText;

    if(!this.serviceProviderUndefined && !this.serviceUndefined && !this.ratingUndefined && !this.reviewTextUndefined){
      this.userService.addReview(this.serviceProvider, this.userService.currentUserName, this.service, this.rating, this.reviewText).subscribe((result: any) =>{
        if(result != false){
          this.router.navigateByUrl('/home-page');
          alert("Review Added");
        }
      });     
    }
  }

  getServices(){
    this.serviceProviderService.getServicesProvided(this.userService.currentUserName, this.serviceProvider).subscribe((services: Service[])=> {
      this.services = [];
      for(let i=0; i<services.length; i++){
        this.services[i] = services[i];
      }
    });
  
  }


}
