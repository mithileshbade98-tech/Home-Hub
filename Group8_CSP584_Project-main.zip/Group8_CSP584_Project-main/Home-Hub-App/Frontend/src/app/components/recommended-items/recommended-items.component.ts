import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentsService } from 'src/app/appointments.service';
import { ServiceProvidersService } from 'src/app/service-providers.service';
import { Service } from 'src/app/types/Service';
import { ServiceProvider } from 'src/app/types/User';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-recommended-items',
  templateUrl: './recommended-items.component.html',
  styleUrls: ['./recommended-items.component.css']
})
export class RecommendedItemsComponent implements OnInit {

  services: any[];
  previouslyUsedServiceProviders: ServiceProvider[];
  recommendedServiceProviders: ServiceProvider[] = [];
  recommendedServiceProvidersFound: boolean = false;

  servicesProvidedToCustomer: Service[];

  constructor(private serviceProviderService: ServiceProvidersService, private appointmentService: AppointmentsService, private userService: UsersService, private router : Router) { }

  ngOnInit(): void {
    this.getPreviouslyUsedServiceProviders()
    this.getServiceTypesProvidedToUser();
  }

  scheduleAppointment(service: string, serviceProvider: string, serviceName: string){
    if(this.userService.currentUserType == "Customer"){
      //console.log(service, serviceProvider);
      this.serviceProviderService.serviceProvider = serviceProvider;
      this.serviceProviderService.service = service;
      this.serviceProviderService.serviceName = serviceName;
      this.router.navigateByUrl('/schedule-appointment');
    }
  }

  getServiceTypesProvidedToUser(){
    this.appointmentService.getServicesProvidedToCustomer(this.userService.currentUserName).subscribe((services: Service[]) =>{
      this.servicesProvidedToCustomer = services;
      this.getAllServiceProviders();
    });
  }

  getAllServiceProviders(){
    this.recommendedServiceProviders = []
    this.appointmentService.getServicesScheduledByCustomer(this.userService.currentUserName).subscribe((serviceProvidersUsed: ServiceProvider[])=>{
      this.previouslyUsedServiceProviders = serviceProvidersUsed;
      for(const service of this.servicesProvidedToCustomer){
        this.serviceProviderService.findServiceProviders(service.service).subscribe((serviceProviders: ServiceProvider[])=>{
          //Get ratings and reviews for each service provider
          serviceProviders.forEach((serviceProvider)=>{
            this.serviceProviderService.getServiceProviderRatingsReviewCount(serviceProvider.name).subscribe((sp: ServiceProvider) =>{
              serviceProvider.rating = sp.rating;
              serviceProvider.review_count = sp.review_count;
              this.setRecommendedServiceProviders(serviceProvider);
              if(this.recommendedServiceProviders.length > 0){
                this.recommendedServiceProvidersFound = true;
              }
            });     
          })
        });
      }
    });
  }

  getPreviouslyUsedServiceProviders(){
    this.appointmentService.getServicesScheduledByCustomer(this.userService.currentUserName).subscribe((serviceProvidersUsed: ServiceProvider[])=>{
      this.previouslyUsedServiceProviders = serviceProvidersUsed;
    });
  }

  setRecommendedServiceProviders(sp: ServiceProvider){
    var alreadyUsed = false;
    for(let i=0;i<this.previouslyUsedServiceProviders.length;i++){
      if(this.previouslyUsedServiceProviders[i].name == sp.name && this.previouslyUsedServiceProviders[i].service == sp.service){
        alreadyUsed = true;
        break;
      }
    }
    if(!alreadyUsed){
      this.recommendedServiceProviders.push(sp);
    }
    if(this.recommendedServiceProviders.length > 5){
      var lowestRated = this.recommendedServiceProviders[0];
      var indexToDelete = 0;
      for(let i = 0; i < this.recommendedServiceProviders.length; i++){
        if(this.recommendedServiceProviders[i].rating < lowestRated.rating){
          lowestRated = this.recommendedServiceProviders[i];
          indexToDelete = i;
        }
      }
      this.recommendedServiceProviders.splice(indexToDelete, 1);
    }
  }
}
