import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/users.service';
import { HeaderComponent } from '../header/header.component';
import { User } from 'src/app/types/User';
import { NgForOf } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
    userName: string;
    password: string;
    type: string;
    users: User[];
    user: User = null;
    loginValid: boolean = true;

    //Header passed to constructor so the user type in header can be changed based on who is logged in
   constructor(private userService : UsersService, private router : Router) { }

   ngOnInit() {}

  //Subscribes to findUser method in user.service and passes usernam and password to it
  //If user data is returned the current user in user.service is set to the user type returned and application navigates to home page
  //Otherwise loginValid is set to false so login error message will be displayed on screen
  public onClickSubmit(form: NgForm) {
    this.userName = form.value.username;
    this.password = form.value.password;
    this.userService.findUser(this.userName, this.password).subscribe((data: User[]) => {
      this.user = data[0];
      if(this.user != null){
        this.userService.currentUserType = this.user.type;
        this.userService.setUserType(this.user.type);
        this.userService.currentUserName = this.userName;
        this.loginValid = true;
        this.router.navigateByUrl('/home-page');
      }
      else{
        this.loginValid = false;
      }
    });
  }
}