import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/types/User';
import { UserType } from 'src/app/types/UserType';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {

  userName: string;
  password: string;
  type: string;
  selectedType: string;
  streetAddress: string;
  city: string;
  state: string;
  zipCode: number;
  email: string;
  phoneNumber: number;
  zipCodeValid: boolean = true;
  phoneNumberValid: boolean = true;

  constructor(private userService : UsersService, private router : Router) { }

  ngOnInit() {
    this.setUserInfo();
  }

  userTypes: UserType[] = [
    {value: "Customer", viewValue: "Customer"},
    {value: "Service Provider", viewValue: "Service Provider"}
  ]

  setUserInfo(){
    this.userService.getUserInfo(this.userService.currentUserName).subscribe((result: User) => {
      this.type = this.userService.currentUserType;
      this.userName = result.name;
      this.password = result.password;
      this.type = result.type;
      this.streetAddress = result.streetAddress;
      this.city = result.city;
      this.state = result.state;
      this.zipCode = result.zipCode;
      this.email = result.email;
      this.phoneNumber = result.phoneNumber;
    });
  }

  changeType(value: string){
    this.type = value;
    console.log(this.type);
  }

  public onClickSubmit(form: NgForm) {
    this.zipCodeValid = true;
    this.phoneNumberValid = true;
    this.userName = this.userService.currentUserName;
    this.password = form.value.password;
    this.streetAddress = form.value.streetaddress;
    this.city = form.value.city;
    this.state = form.value.state;
    this.zipCode = form.value.zipcode;
    this.email = form.value.email;
    this.phoneNumber = form.value.phonenumber;

    if(isNaN(form.value.zipcode)){
      this.zipCodeValid = false;
    } 
    else{
      this.zipCode = parseInt(form.value.zipcode);
    }
    
    if(isNaN(form.value.phonenumber)){
      this.phoneNumberValid = false;
    } 
    else{
      this.phoneNumber = parseInt(form.value.phonenumber);
    }

    if(this.phoneNumberValid && this.zipCodeValid){
      this.userService.updateUser(this.userName, this.password, this.type, this.streetAddress, this.city, this.state, this.zipCode, this.email, this.phoneNumber).subscribe((updated: boolean) => {
        if(updated){
          this.router.navigateByUrl('/home-page');
        }
      });
    }
  }

}
