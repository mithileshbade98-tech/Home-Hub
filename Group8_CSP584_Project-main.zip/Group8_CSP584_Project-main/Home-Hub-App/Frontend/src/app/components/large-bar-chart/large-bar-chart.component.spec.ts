import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LargeBarChartComponent } from './large-bar-chart.component';

describe('LargeBarChartComponent', () => {
  let component: LargeBarChartComponent;
  let fixture: ComponentFixture<LargeBarChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LargeBarChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LargeBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
