import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-large-bar-chart',
  templateUrl: './large-bar-chart.component.html',
  styleUrls: ['./large-bar-chart.component.css']
})
export class LargeBarChartComponent implements OnInit {

  @Input() data: any[];
  view: any[] = [1000,400];
  schemeType: string = 'ordinal';
  gradient: boolean = false;
  xAxis: boolean = true;
  yAxis: boolean = true;
  legend: boolean = true;
  showXAxisLabel: boolean = true;
  showYAxisLabel: boolean = true;
  @Input() xAxisLabel: string;
  @Input() yAxisLabel: string;
  @Input() legendTitle: string;
  legendPosition: string = "below";
  animations: boolean = true;
  showGridLines: boolean = true;
  showDataLabel: boolean = true;
  barPadding: number = 5;
  tooltipDisabled: boolean = false;
  roundEdges: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

}
