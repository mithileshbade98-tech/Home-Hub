import {Option} from './types/Option'

export const INTERIOR_OPTIONS: Option[] = [
    {
        id: 'carpet_cleaning',
        name: 'Carpet Cleaning',
    },
    {
        id: 'drywall',
        name: 'Drywall',
    },
    {
        id: 'electrical',
        name: 'Electrical',
    },
    {
        id: 'flooring',
        name: 'Flooring',
    },
    {
        id: 'hvac',
        name: 'HVAC',
    },
    {
        id: 'housecleaning',
        name: 'House Cleaning',
    },
    {
        id: 'painting',
        name: 'Painting',
    },
    {
        id: 'plumbing',
        name: 'Plumbing',
    },
]