import { state } from '@angular/animations';
import { Time } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { Appointment } from './types/Appointment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class AppointmentsService {

  serviceProvider: string;
  startTime: Time;
  endTime: Time;
  dayServicePerformed: Date;
  amountDue: number;
  service: string;

  constructor(private http: HttpClient) { }

  uri = 'http://localhost:4000';

  findFutureAppointments(username: string, userType: string) {
    if(userType == "Customer"){
      const find_future_customer_appointments_with = {
        customer: username
      }

      JSON.stringify(find_future_customer_appointments_with, null, 2);

      return this.http.post(`${this.uri}/find-customer-future-appointments`, find_future_customer_appointments_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const find_future_service_provider_appointments_with = {
        serviceprovider: username
      }

      JSON.stringify(find_future_service_provider_appointments_with, null, 2);

      return this.http.post(`${this.uri}/find-service-provider-future-appointments`, find_future_service_provider_appointments_with, httpOptions);
    }
  }

  cancelAppointment(customer: string, serviceProvider: string, serviceStartTime: Time, dayServicePerformed: Date){
    const cancel_appointment_with = {
      customer: customer,
      serviceprovider: serviceProvider,
      servicestarttime: serviceStartTime,
      dayserviceperformed: dayServicePerformed
    }

    JSON.stringify(cancel_appointment_with, null, 2);

    return this.http.post(`${this.uri}/cancel-appointment`, cancel_appointment_with, httpOptions);
  }

  updateAppointment(oldStartTime: Time, oldDayServicePerformed: string, startTime: Time, endTime: Time, dayServicePerformed: string, serviceProvider: string, currentUserName: string, totalCost: number){
    const update_appointment_with = {
      oldstarttime: oldStartTime,
      olddayserviceperformed: oldDayServicePerformed,
      starttime: startTime,
      endtime: endTime,
      dayserviceperformed: dayServicePerformed,
      serviceprovider: serviceProvider,
      currentusername: currentUserName,
      servicecost: totalCost
    }

    JSON.stringify(update_appointment_with, null, 2);

    return this.http.post(`${this.uri}/update-appointment`, update_appointment_with, httpOptions);
  }

  findPreviousAppointments(username: string, userType: string) {
    if(userType == "Customer"){
      const find_previous_appointments_with = {
        customer: username
      }

      JSON.stringify(find_previous_appointments_with, null, 2);

      return this.http.post(`${this.uri}/find-previous-customer-appointments`, find_previous_appointments_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const find_previous_appointments_with = {
        serviceprovider: username
      }

      JSON.stringify(find_previous_appointments_with, null, 2);

      return this.http.post(`${this.uri}/find-previous-service-provider-appointments`, find_previous_appointments_with, httpOptions);
    }

  }

  makePayment(customer: string, amountDue: number) {
    var daysrvprf = moment(this.dayServicePerformed).format('YYYY-MM-DD');
    const make_payment_with = {
      customer: customer,
      amountdue: amountDue,
      serviceprovider: this.serviceProvider,
      dayserviceperformed: daysrvprf,
      servicestarttime: this.startTime
    }

    JSON.stringify(make_payment_with, null, 2);

    return this.http.post(`${this.uri}/make-payment`, make_payment_with, httpOptions);
  }

  getServiceCost(serviceProvider: string, service: string){
    const get_service_cost_with = {
      serviceprovider: serviceProvider,
      service: service
    }

    JSON.stringify(get_service_cost_with, null, 2);

    return this.http.post(`${this.uri}/get-service-cost`, get_service_cost_with, httpOptions);
  }

  addAppointmentToCart(dayServicePerformed: string, startTime: Time, endTime: Time, serviceProvider: string, cost: number, service: string, userStreetAddress : string,
     userCity: string, userState: string, userZipCode: number){
    
      const add_appointment_to_cart_with = {
      dayserviceperformed: dayServicePerformed,
      servicestarttime: startTime,
      serviceendtime: endTime,
      serviceprovider: serviceProvider,
      servicecost: cost,
      service: service,
      streetaddress: userStreetAddress,
      city: userCity,
      state: userState, 
      zipcode: userZipCode
    }

    JSON.stringify(add_appointment_to_cart_with, null, 2);

    return this.http.post(`${this.uri}/add-appopintment-to-cart`, add_appointment_to_cart_with, httpOptions);
  }

  getCartItems(){

    return this.http.get(`${this.uri}/get-cart-itmes`);

  }

  removeCartItem(serviceProvider: string, startTime: Time, dayServicePerformed: Date){
    const remove_cart_item_with = {
      dayserviceperformed: dayServicePerformed,
      servicestarttime: startTime,
      serviceprovider: serviceProvider
    }

    JSON.stringify(remove_cart_item_with, null, 2);

    return this.http.post(`${this.uri}/remove-cart-item`, remove_cart_item_with, httpOptions);
  
  }

  createAppointment(cartItem: Appointment, customer: string){
    const create_appointment_with = {
      dayserviceperformed: cartItem.dayServicePerformed,
      servicestarttime: cartItem.serviceStartTime,
      serviceendtime: cartItem.serviceEndTime,
      serviceprovider: cartItem.serviceProvider,
      customer: customer,
      servicecost: cartItem.serviceCost,
      amountdue: cartItem.serviceCost,
      service: cartItem.service,
      streetaddress: cartItem.streetAddress,
      city: cartItem.city,
      state: cartItem.state,
      zipcode: cartItem.zipCode
    }

    //console.log(create_appointment_with);
    JSON.stringify(create_appointment_with, null, 2);

    return this.http.post(`${this.uri}/create-appointment`, create_appointment_with, httpOptions);

  }

  clearCart(){

    return this.http.get(`${this.uri}/clear_cart`);

  }

  getPreviousServicesReceivedByMonth(user: string, userType: string){
    if(userType == "Customer"){
      const get_previous_services_received_by_month_with = {
        customer: user
      }
  
      JSON.stringify(get_previous_services_received_by_month_with, null, 2);
  
      return this.http.post(`${this.uri}/find-previous-services-received-by-month`, get_previous_services_received_by_month_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_previous_services_provided_by_month_with = {
        serviceprovider: user
      }
  
      JSON.stringify(get_previous_services_provided_by_month_with, null, 2);
  
      return this.http.post(`${this.uri}/find-previous-services-provided-by-month`, get_previous_services_provided_by_month_with, httpOptions);
    }
  }

  getPreviousServicesReceived(user: string, userType: string){
    if(userType == "Customer"){
      const get_previous_services_received_with = {
        customer: user
      }

      JSON.stringify(get_previous_services_received_with, null, 2);

      return this.http.post(`${this.uri}/find-previous-services-received-by-service`, get_previous_services_received_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_previous_services_provided_with = {
        serviceprovider: user
      }

      JSON.stringify(get_previous_services_provided_with, null, 2);

      return this.http.post(`${this.uri}/find-previous-services-provided-by-service`, get_previous_services_provided_with, httpOptions);
    }
  }

  getAmountPaidForPreviousServicesByMonth(user: string, userType: string){
    if(userType == "Customer"){
      const get_amount_paid_for_previous_services_with = {
        customer: user
      }

      JSON.stringify(get_amount_paid_for_previous_services_with, null, 2);

      return this.http.post(`${this.uri}/find-amount-paid-for-previous-services-by-month`, get_amount_paid_for_previous_services_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_amount_received_for_previous_services_with = {
        serviceprovider: user
      }

      JSON.stringify(get_amount_received_for_previous_services_with, null, 2);

      return this.http.post(`${this.uri}/find-amount-received-for-previous-services-by-month`, get_amount_received_for_previous_services_with, httpOptions);
    }
  }

  getFutureServicesReceivedByMonth(user: string, userType: string){
    if(userType == "Customer"){
      const get_future_services_received_by_month_with = {
        customer: user
      }
  
      JSON.stringify(get_future_services_received_by_month_with, null, 2);
  
      return this.http.post(`${this.uri}/find-future-services-received-by-month`, get_future_services_received_by_month_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_future_services_provided_by_month_with = {
        serviceprovider: user
      }
  
      JSON.stringify(get_future_services_provided_by_month_with, null, 2);
  
      return this.http.post(`${this.uri}/find-future-services-provided-by-month`, get_future_services_provided_by_month_with, httpOptions);
    }
  }

  getFutureServicesReceived(user: string, userType: string){
    if(userType == "Customer"){
      const get_future_services_received_by_month_with = {
        customer: user
      }

      JSON.stringify(get_future_services_received_by_month_with, null, 2);

      return this.http.post(`${this.uri}/find-future-services-received-by-service`, get_future_services_received_by_month_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_future_services_provided_with = {
        serviceprovider: user
      }

      JSON.stringify(get_future_services_provided_with, null, 2);

      return this.http.post(`${this.uri}/find-future-services-provided-by-service`, get_future_services_provided_with, httpOptions);
    }
  }

  getAmountPaidForFutureServicesByMonth(user: string, userType: string){
    if(userType == "Customer"){
      const get_amount_paid_for_future_services_with = {
        customer: user
      }

      JSON.stringify(get_amount_paid_for_future_services_with, null, 2);

      return this.http.post(`${this.uri}/find-amount-paid-for-future-services-by-month`, get_amount_paid_for_future_services_with, httpOptions);
    }
    else if(userType == "Service Provider"){
      const get_amount_received_for_future_services_with = {
        serviceprovider: user
      }

      JSON.stringify(get_amount_received_for_future_services_with, null, 2);

      return this.http.post(`${this.uri}/find-amount-received-for-future-services-by-month`, get_amount_received_for_future_services_with, httpOptions);
    }
  }

  getFutureServicesByDay(serviceProvider: string){
    const get_future_services_by_day_with = {
      serviceprovider: serviceProvider
    }

    JSON.stringify(get_future_services_by_day_with, null, 2);

    return this.http.post(`${this.uri}/find-future-services-by-day`, get_future_services_by_day_with, httpOptions);
  }

  getAppointmentsByDateTime(date: Date, serviceProvider: string, serviceStartTime: Time, serviceEndTime: Time,){
    const get_appointments_by_date_time_with = {
      date: date,
      serviceprovider: serviceProvider,
      servicestarttime: serviceStartTime,
      serviceendtime: serviceEndTime
    }

    JSON.stringify(get_appointments_by_date_time_with, null, 2);

    return this.http.post(`${this.uri}/find-appointments-by-date-time`, get_appointments_by_date_time_with, httpOptions);
  }

  getServicesProvidedToCustomer(customer: string){
    if(customer == null){
      customer = "none";
    }
    const get_services_provided_to_customer_with = {
      customer: customer
    }

    JSON.stringify(get_services_provided_to_customer_with, null, 2);

    return this.http.post(`${this.uri}/find-services-provided-to-customer`, get_services_provided_to_customer_with, httpOptions);
  }

  getServicesScheduledByCustomer(customer: string){
    if(customer == null){
      customer = "none";
    }
    const get_services_scheduled_by_customer_with = {
      customer: customer
    }

    JSON.stringify(get_services_scheduled_by_customer_with, null, 2);

    return this.http.post(`${this.uri}/find-services-scheduled-by-customer`, get_services_scheduled_by_customer_with, httpOptions);
  }
}
