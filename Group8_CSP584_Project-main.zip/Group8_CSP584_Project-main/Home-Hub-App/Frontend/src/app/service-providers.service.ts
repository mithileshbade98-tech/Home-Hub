import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ListOfServiceProvidersComponent } from './components/list-of-service-providers/list-of-service-providers.component';
import { EXTERIOR_OPTIONS } from './exterior-options';
import { INTERIOR_OPTIONS } from './interior-options';
import { LAWN_GARDEN_OPTIONS } from './lawn-garden-options';
import { Option } from './types/Option';
import { Review } from './types/Review';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class ServiceProvidersService {

  uri = 'http://localhost:4000';

  chosenOption: Option;
  private chosenOptionChange: BehaviorSubject<Option>

  //Used when scheduling services
  serviceProvider: string;
  service: string;
  serviceName: string;

  interiorOptions = INTERIOR_OPTIONS;
  exteriorOptions = EXTERIOR_OPTIONS;
  lawnGardenOptions = LAWN_GARDEN_OPTIONS;
  options: Option[] = [];

  reviewToRespondTo: Review;


  constructor(private http: HttpClient) { 
    this.chosenOptionChange = new BehaviorSubject<Option>(null);
  }

  setChosenOption(option: Option){
    this.chosenOptionChange.next(option);
  }

  getChosenOption(){
    return this.chosenOptionChange.asObservable();
  }

  getServices(){
    this.options = [];
    var j = 0;
    for(let i = 0; i<this.interiorOptions.length; i++){
      this.options[j] = this.interiorOptions[i];
      j += 1;
    }
    for(let i = 0; i<this.exteriorOptions.length; i++){
      this.options[j] =this.exteriorOptions[i];
      j += 1;
    }
    for(let i = 0; i<this.lawnGardenOptions.length; i++){
      this.options[j] =this.lawnGardenOptions[i];
      j += 1;
    }
    return this.options;
  }

  findServiceProviders(serviceType: string) {
    const find_service_providers_with = {
      servicetype: serviceType
    }

    JSON.stringify(find_service_providers_with, null, 2);

    return this.http.post(`${this.uri}/find-service-providers`, find_service_providers_with, httpOptions);
  }

  getServiceProviderRatingsReviewCount(name: string){
    const get_review_counts_ratings_with = {
      name: name
    }

    JSON.stringify(get_review_counts_ratings_with, null, 2);

    return this.http.post(`${this.uri}/get-review-counts-ratings`, get_review_counts_ratings_with, httpOptions);
  }

  addService(currentUserName: string, optionId: string, costPerHour: number){

    const add_service_with = {
      username: currentUserName,
      service: optionId,
      costperhour: costPerHour
    }

    JSON.stringify(add_service_with, null, 2);

    return this.http.post(`${this.uri}/add-service`, add_service_with, httpOptions);

  }

  getCurrentServices(currentUserName: string){
    const get_current_services_with = {
      username: currentUserName
    }

    JSON.stringify(get_current_services_with, null, 2);

    return this.http.post(`${this.uri}/get-current-services`, get_current_services_with, httpOptions);
  }

  removeService(currentUserName: string, service: string){
    const remove_service_with = {
      username: currentUserName,
      service: service
    }
    
    JSON.stringify(remove_service_with, null, 2);

    return this.http.post(`${this.uri}/remove-service`, remove_service_with, httpOptions);
  }
  
  findPreviousServiceProviders(customer: string) {
    const find_previous_service_providers_with = {
      customer: customer
    }

    JSON.stringify(find_previous_service_providers_with, null, 2);

    return this.http.post(`${this.uri}/find-previous-service-providers`, find_previous_service_providers_with, httpOptions);
  }

  getServicesProvided(customer: string, serviceProvider: string) {
    const find_services_provided_with = {
      customer: customer,
      serviceprovider: serviceProvider
    }

    JSON.stringify(find_services_provided_with, null, 2);

    return this.http.post(`${this.uri}/get-services-provided`, find_services_provided_with, httpOptions);
  }

  getMostPopularServices(){
    return this.http.get(`${this.uri}/get-most-popular-services`);
  }

  findAllServiceProviders() {
    return this.http.get(`${this.uri}/find-all-service-providers`);
  }

  findAllServices(){
    return this.http.get(`${this.uri}/find-all-services`);
  }

  findAllServiceIDs(){
    return this.http.get(`${this.uri}/find-all-service-ids`);
  }

  getServiceId(service: string){
    const find_service_id_with = {
      service: service
    }

    JSON.stringify(find_service_id_with, null, 2);

    return this.http.post(`${this.uri}/get-service-id`, find_service_id_with, httpOptions);
  }

  findReviewsByServiceType(service: string) {
    const find_reviews_by_service_type_with = {
      service: service
    }

    JSON.stringify(find_reviews_by_service_type_with, null, 2);

    return this.http.post(`${this.uri}/get-reviews-by-service-type`, find_reviews_by_service_type_with, httpOptions);
  }

  findReviewsByServiceProviderName(serviceProvider: string) {
    const find_reviews_by_service_provider_name_with = {
      serviceProvider: serviceProvider
    }

    JSON.stringify(find_reviews_by_service_provider_name_with, null, 2);

    return this.http.post(`${this.uri}/get-reviews-by-service-provider-name`, find_reviews_by_service_provider_name_with, httpOptions);
  }

  addReviewResponse(_id: string, response: string) {
    const add_review_response_with = {
      _id: _id,
      response: response
    }

    JSON.stringify(add_review_response_with, null, 2);

    return this.http.post(`${this.uri}/add-review-response`, add_review_response_with, httpOptions);
  }

  
  getNumberServicesProvided() {
    return this.http.get(`${this.uri}/get-number-of-services-provided`);
  }

  getHighestRatedServiceProviders() {
    return this.http.get(`${this.uri}/get-highest-reviewed-service-providers`);
  }

  getServiceRevenue() {
    return this.http.get(`${this.uri}/get-service-revenue`);
  }

  getHardwareStores(){
    return this.http.get(`${this.uri}/find-hardware-stores`);
  }

  getHighestRatedServiceProvidersByCategory(service: string) {
    const get_highest_rated_service_providers_by_category_with = {
      service : service
    }

    JSON.stringify(get_highest_rated_service_providers_by_category_with, null, 2);

    return this.http.post(`${this.uri}/get-highest-rated-service-providers-by-category`, get_highest_rated_service_providers_by_category_with, httpOptions);
  }

  getAllServiceProviderRatings() {
    return this.http.get(`${this.uri}/get-all-service-provider-ratings`);
  }
}
