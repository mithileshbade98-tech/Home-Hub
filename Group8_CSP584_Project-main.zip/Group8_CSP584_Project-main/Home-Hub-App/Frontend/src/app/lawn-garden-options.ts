import {Option} from './types/Option'

export const LAWN_GARDEN_OPTIONS: Option[] = [
    {
        id: 'fences_gates',
        name: 'Fences & Gates',
    },
    {
        id: 'landscaping',
        name: 'Landscaping',
    },
    {
        id: 'decks_railing',
        name: 'Decks & Railing',
    },
    {
        id: 'snow_removal',
        name: 'Snow Removal',
    },

]