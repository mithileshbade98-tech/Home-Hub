//  Install Nodejs (the bundle includes the npm) from the following website:
//      https://nodejs.org/en/download/


//  Before you start nodejs make sure you install from the
//  command line window/terminal the following packages:
//      1. npm install express
//      2. npm install pg
//      3. npm install pg-format
//      4. npm install moment --save
//      5. npm install mongoose --save

const express = require('express');
var pg = require('pg');
var bodyParser = require('body-parser');
const moment = require('moment');
const mongooose = require('mongoose');


const app = express();
const router = express.Router();

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

app.use('/', router);

app.listen(4000, () => {
  console.log('Express server running on port 4000')
});

router.all('*', function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

// mongo Db connection 
mongooose.connect('mongodb://localhost:27017/Group8_CSP584_Project', { useNewUrlParser: true, useUnifiedTopology: true }).then(() => {
  console.log('Mondo Db server Connected');
})

const Schema = mongooose.Schema;

const ServiceProviderSchema = new Schema({
    id: { type: String },
    alias: { type: String },
    name: { type: String },
    image_url: { type: String },
    is_closed: { type: Boolean },
    url: { type: String },
    reviewCount: { type: Number },
    categories: [{alias: { type: String }, title: { type: String }}],
    rating: { type: Number },
    coordinates: [{latitude: { type: Number }, longitude: { type: Number }}],
    location: [{address1: { type: String }, city: { type: String }, zip_code: { type: Number }, country: { type: String }, state: { type: String }}],
    phone: { type: String },
    display_phone: { type: String },
});
// Note MongoDB collections shd always be PLURAL.
// use the collection name that stores searches
const businessdata = "businessdatas"
var ServiceModel = mongooose.model(businessdata, ServiceProviderSchema);
module.exports = ServiceModel;

/*const ReviewsSchema = new Schema({
  id: String,
  alias: String,
  name: String,
  image_url: String,
  is_closed: Boolean,
  url: String,
  reviewCount: Number,
  categories: [{alias: String, title: String}],
  rating: Number,
  coordinates: [{latitude: Number, longitude: Number}],
  location: [{address1: String, city: String, zip_code: Number, country: String, state: String}],
  phone: String,
  display_phone: String
});*/
const ReviewsSchema = new Schema({
  date: { type: Date },
  service_provider: { type: String },
  customer: { type: String },
  service: { type: String },
  rating: { type: Number },
  review_text: { type: String },
  response: { type: String },
});
const businessreviews = "businessreviews"
var ReviewModel = mongooose.model(businessreviews, ReviewsSchema);
module.exports = ReviewModel;



var review_counts_ratings = [];
var added_review;
var reviews_by_service_type = [];
var reviews_by_service_provider_name = [];
var response_added;
var highest_reviewed_service_providers = [];
var highest_rated_service_providers_by_category = [];
var service_provider_ratings = [];

//Functions to get business data
router.route('/get-review-counts-ratings').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_review_counts_and_ratings(req.body.name).then(function(){
    res.json(review_counts_ratings);
  });
});

async function get_review_counts_and_ratings(name){
  review_counts_ratings = [];
  const result = await getBuisnessSearch(name ,ServiceModel);
  review_counts_ratings = result;
}

const getBuisnessSearch = async (name,Model)  => {
  const result = await Model.findOne({name : name})
  //console.log(result);
  return result;
}

//Functions to add a review
router.route('/add-review').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  add_review(req.body.serviceProvider, req.body.customer, req.body.service, req.body.rating, req.body.reviewText).then(function(){
    res.json(added_review);
  });
});

const add_review = async (serviceProvider, customer, service, rating, reviewText)  => {
  var today = new Date();
  var new_review = new ReviewModel({date: today,
                                    service_provider: serviceProvider,
                                    customer: customer,
                                    service: service,
                                    rating: rating,
                                    review_text: reviewText,
                                    response: ""});
  const result = new_review.save(function(err,result){
    if (err){
        console.log(err);
        added_review = false;
    }else{
        //console.log(result);
        added_review = true;
    }
  });
}

//Functions to get reviews by service
router.route('/get-reviews-by-service-type').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_reviews_by_service_type(req.body.service).then(function(){
    res.json(reviews_by_service_type);
  });
});

const get_reviews_by_service_type = async (service)  => {
  const result = await ReviewModel.find({service : service})
  reviews_by_service_type = result;
}

//Functions to get reviews by service provider name
router.route('/get-reviews-by-service-provider-name').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_reviews_by_service_provider_name(req.body.serviceProvider).then(function(){
    res.json(reviews_by_service_provider_name);
  });
});

const get_reviews_by_service_provider_name = async (serviceProvider)  => {
  const result = await ReviewModel.find({service_provider : serviceProvider})
  reviews_by_service_provider_name = result;
}

//Functions to add response to review
router.route('/add-review-response').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  add_review_response(req.body._id, req.body.response).then(function(){
    res.json(response_added);
  });
});

const add_review_response = async (id, responseToReview)  => {
  await ReviewModel.findByIdAndUpdate({_id: id}, {$set: {response: responseToReview}}, { new: true }, function (err, docs) {
    if (err){
        console.log(err)
    }
    else{
        //console.log("Updated Docs : ", docs);
        response_added = true;
    }
}).clone();
}

router.route('/get-highest-reviewed-service-providers').get((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_highest_reviewed_service_providers().then(function(){
    res.json(highest_reviewed_service_providers);
  });
});

const get_highest_reviewed_service_providers = async ()  => {
  ServiceModel.find().sort({rating: -1}).limit(5).exec(function (err, result) {
    if (err){
        console.log(err)
    }
    else{
        //console.log("Docs : ", result);
        highest_reviewed_service_providers = result;
    }
  })
}

//Functions to get highest rated service providers by category
router.route('/get-highest-rated-service-providers-by-category').post((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_highest_rated_service_providers_by_category(req.body.service).then(function(){
    res.json(highest_rated_service_providers_by_category);
  });
});

const get_highest_rated_service_providers_by_category = async (service)  => {
  ServiceModel.find({"categories.alias" : service}).sort({rating: -1}).limit(4).exec(function (err, result) {
    if (err){
        console.log(err)
    }
    else{
        //console.log("Docs : ", result);
        highest_rated_service_providers_by_category = result;
    }
  })
}

//Functions to get all service provider ratings
router.route('/get-all-service-provider-ratings').get((req, res) => {
  var str = JSON.stringify(req.body, null, 4);
  get_all_service_provider_ratings().then(function(){
    res.json(service_provider_ratings);
  });
});

const get_all_service_provider_ratings = async ()  => {
  ServiceModel.find({}).sort({rating: -1}).exec(function (err, result) {
    if (err){
        console.log(err)
    }
    else{
        //console.log("Docs : ", result);
        service_provider_ratings = result;
    }
  })
}




//Postgres SQL Connection
var pg = require('pg');
const { request } = require('express');
var pgConString = "pg://postgres:root@127.0.0.1:5432/Home_Hub_App";
var pgClient = new pg.Client(pgConString);
pgClient.connect();

pgClient.query('SELECT * from Users', (err, res) => {
  console.log("PostgreSQL connected")
  //pgClient.end()
})

var users_found = [];
var user_found = [];
var user_info = null;
var added;
var updated;
var appointments_found = [];
var deleted;
var service_providers_found = [];
var payment_made;
var service_cost;
var user_address;
var added_to_cart;
var cart_items = [];
var removed_from_cart;
var appointment_created;
var cart_cleared;
var service_added;
var current_services = [];
var service_deleted;
var future_service_provider_appointments_found = [];
var previous_service_provider_appointments_found = [];
var previous_service_providers_found = []
var users_found_with_username;
var services_provided = [];
var video_ids = [];
var previous_services_received_by_month = [];
var previous_services_received_by_service = [];
var amount_paid_for_previous_services = [];
var previous_services_provided_by_month = [];
var previous_services_provided_by_service = [];
var amount_received_for_previous_services = [];
var future_services_received_by_month = [];
var future_services_received_by_service = [];
var amount_paid_for_future_services = [];
var future_services_provided_by_month = [];
var future_services_provided_by_service = [];
var amount_received_for_future_services = [];
var most_popular_services = [];
var all_service_providers_found = [];
var all_services_found = [];
var service_id;
var all_service_ids_found = [];
var number_of_services_provided = [];
var service_revenue = [];
var future_services_per_day = [];
var appointments_by_date_time = [];
var hardware_stores_found = [];
var services_provided_to_customer = [];
var services_scheduled_by_customer = [];
var customer_location_added;
var service_provider_location_added;

router.route('/find-users').get((req, res) => {
  get_users().then(function(){
    res.json(users_found);
  });
});

router.route('/find-user').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'fetch-user',
    text: 'SELECT * FROM Users WHERE username = $1 and password = $2;',
    values: [req.body.username, req.body.password]

  }
  get_user(query).then(function(response){
    res.json(user_found);
  });
});

router.route('/add-user').post((req, res) => {
  JSON.stringify(req.body, null, 4);
  
  const query = {
    name: 'add-user',
    text: 'INSERT INTO Users(username, password, type, streetaddress, city, state, zipcode, email, phonenumber) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9);',
    values: [req.body.username, req.body.password, req.body.type, req.body.streetaddress, req.body.city, req.body.state, req.body.zipcode, req.body.email, req.body.phonenumber]
  }

  add_user(query).then(function(){
    res.json(added);
  })
});

router.route('/get-user-info').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'fetch-user-info',
    text: 'SELECT * FROM Users WHERE username = $1;',
    values: [req.body.username]

  }
  get_user_info(query).then(function(){
    res.json(user_info);
  });
});

router.route('/update-user').post((req, res) => {
  JSON.stringify(req.body, null, 4);
  
  const query = {
    name: 'update-user',
    text: 'UPDATE Users SET password = $2, type = $3, streetaddress = $4, city = $5, state = $6, zipcode = $7, email = $8, phonenumber = $9 WHERE userName = $1;',
    values: [req.body.username, req.body.password, req.body.type, req.body.streetaddress, req.body.city, req.body.state, req.body.zipcode, req.body.email, req.body.phonenumber]
  }

  update_user(query).then(function(){
    res.json(updated);
  })
});

router.route('/find-customer-future-appointments').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'fetch-customer-future-appointments',
    text: 'SELECT * FROM Appointments NATURAL JOIN serviceids WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE);',
    values: [req.body.customer]

  }
  get_customer_future_appointments(query).then(function(){
    res.json(appointments_found);
  });
});

router.route('/cancel-appointment').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'cancel-appointment',
    text: 'DELETE FROM appointments WHERE customer=$1 AND serviceprovider=$2 and servicestarttime=$3 AND dayserviceperformed=$4;',
    values: [req.body.customer, req.body.serviceprovider, req.body.servicestarttime, req.body.dayserviceperformed]

  }
  delete_appointment(query).then(function(){
    res.json(deleted);
  });
});

router.route('/update-appointment').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'update-appointment',
    text: 'UPDATE appointments SET dayserviceperformed=$1, servicestarttime=$2, serviceendtime=$3, servicecost=$4, amountdue=$5 WHERE serviceprovider=$6 AND customer=$7 AND servicestarttime=$8 AND dayserviceperformed=$9;',
    values: [req.body.dayserviceperformed, req.body.starttime, req.body.endtime, req.body.servicecost, req.body.servicecost, req.body.serviceprovider, req.body.currentusername, req.body.oldstarttime, req.body.olddayserviceperformed]

  }
  update_appointment(query).then(function(){
    res.json(updated);
  });
});

router.route('/find-previous-customer-appointments').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'fetch-previous-customer-appointments',
    text: 'SELECT * FROM Appointments NATURAL JOIN serviceids WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND serviceendtime <= CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE);',
    values: [req.body.customer]

  }
  get_customer_previous_appointments(query).then(function(){
    res.json(appointments_found);
  });
});

router.route('/make-payment').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'make-payment',
    text: 'UPDATE appointments SET amountdue = $1 WHERE customer = $2 AND serviceprovider = $3 AND dayserviceperformed = $4 AND servicestarttime = $5;',
    values: [req.body.amountdue, req.body.customer, req.body.serviceprovider, req.body.dayserviceperformed, req.body.servicestarttime]

  }
  make_payment(query).then(function(){
    res.json(payment_made);
  });
});

router.route('/find-service-providers').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-service-providers',
    //24140.2 meters in 15 miles
    //Search radius is 15 miles
    text: 'SELECT * from serviceproviderlocation NATURAL JOIN Services NATURAL JOIN Users NATURAL JOIN serviceids WHERE ST_DWithin(serviceProviderLocation.userlocation, ST_MakePoint(-87.627472, 41.838902), 24140.2) AND service = $1 ORDER BY (serviceProviderLocation.userlocation <-> ST_POINT(-87.627472, 41.838902));',
    values: [req.body.servicetype]

  }

  get_service_providers(query).then(function(){
    res.json(service_providers_found)
  });
});

router.route('/find-previous-service-providers').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-service-providers',
    text: 'SELECT * from appointments WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE);',
    values: [req.body.customer]

  }

  get_previous_service_providers(query).then(function(){
    res.json(previous_service_providers_found)
  });
});

router.route('/get-service-cost').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'get-service-cost',
    text: 'SELECT costperhour FROM Services WHERE username = $1 AND service = $2',
    values: [req.body.serviceprovider, req.body.service]

  }
  get_service_cost(query).then(function(){
    res.json(service_cost);
  });
});

router.route('/get-user-address').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'get-user-address',
    text: 'SELECT streetaddress, city, state, zipcode FROM Users WHERE username = $1',
    values: [req.body.username]

  }
  get_user_address(query).then(function(){
    res.json(user_address);
  });
});

router.route('/add-appopintment-to-cart').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'add-appopintment-to-cart',
    text: 'INSERT INTO cart(dayserviceperformed, servicestarttime, serviceendtime, serviceprovider, servicecost, service, streetaddress, city, state, zipcode)' + 
          ' VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
    values: [req.body.dayserviceperformed, req.body.servicestarttime, req.body.serviceendtime, req.body.serviceprovider, req.body.servicecost, req.body.service, 
      req.body.streetaddress, req.body.city, req.body.state, req.body.zipcode]

  }
  add_appopintment_to_cart(query).then(function(){
    res.json(added_to_cart);
  });
});

router.route('/get-cart-itmes').get((req, res) => {
  get_cart_items().then(function(){
    res.json(cart_items);
  });
});

router.route('/remove-cart-item').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'remove-cart-item',
    text: 'DELETE FROM cart WHERE dayserviceperformed=$1 AND servicestarttime=$2 AND serviceprovider=$3',
    values: [req.body.dayserviceperformed, req.body.servicestarttime, req.body.serviceprovider]

  }
  remove_cart_item(query).then(function(){
    res.json(removed_from_cart);
  });
});

router.route('/create-appointment').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'create-appointment',
    text: 'INSERT INTO appointments (dayserviceperformed, servicestarttime, serviceendtime, serviceprovider, customer, servicecost, amountdue, service, streetaddress, city, state, zipcode)'+
          ' VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)',
    values: [req.body.dayserviceperformed, req.body.servicestarttime, req.body.serviceendtime, req.body.serviceprovider, req.body.customer, req.body.servicecost, 
      req.body.amountdue, req.body.service, req.body.streetaddress, req.body.city, req.body.state, req.body.zipcode]

  }
  create_appointment(query).then(function(){
    res.json(appointment_created);
  });
});

router.route('/clear_cart').get((req, res) => {
  clear_cart().then(function(){
    res.json(cart_cleared);
  });
});

router.route('/add-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'add-service',
    text: 'INSERT INTO services (username, service, costperhour) VALUES ($1, $2, $3);',
    values: [req.body.username, req.body.service, req.body.costperhour]
  }

  create_service(query).then(function(){
    res.json(service_added);
  });
});

router.route('/get-current-services').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'get-current-services',
    text: 'SELECT * FROM services WHERE username = $1;',
    values: [req.body.username]
  }

  get_current_services(query).then(function(){
    res.json(current_services);
  });
});

router.route('/remove-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'remove-service',
    text: 'DELETE FROM services WHERE username = $1 AND service = $2;',
    values: [req.body.username, req.body.service]
  }

  remove_service(query).then(function(){
    res.json(service_deleted);
  });
});

router.route('/find-previous-service-provider-appointments').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-service-provider-appointments',
    text: 'SELECT * FROM Appointments NATURAL JOIN serviceids WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND serviceendtime <= CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE);',
    values: [req.body.serviceprovider]

  }
  get_service_provider_previous_appointments(query).then(function(){
    res.json(previous_service_provider_appointments_found);
  });
});

router.route('/find-service-provider-future-appointments').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-service-provider-future-appointments',
    text: 'SELECT * FROM Appointments NATURAL JOIN serviceids WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE);',
    values: [req.body.serviceprovider]

  }
  get_service_provider_future_appointments(query).then(function(){
    res.json(future_service_provider_appointments_found);
  });
});

router.route('/check-if-user-exists').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'check-if-user-exists',
    text: 'SELECT COUNT(1) FROM Users WHERE username = $1;',
    values: [req.body.username]

  }
  check_if_user_exists(query).then(function(){
    res.json(users_found_with_username);
  });
});

router.route('/get-services-provided').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'get-services-provided',
    text: 'SELECT DISTINCT service, servicename FROM Appointments NATURAL JOIN serviceids WHERE customer = $1 AND serviceprovider = $2;',
    values: [req.body.customer, req.body.serviceprovider]

  }
  get_services_provided(query).then(function(){
    res.json(services_provided);
  });
});

router.route('/get-video-ids').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'get-video-ids',
    text: 'SELECT videoid FROM YoutubeVideos WHERE type = $1;',
    values: [req.body.type]

  }
  get_video_ids(query).then(function(){
    res.json(video_ids);
  });
});

router.route('/find-previous-services-received-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-services-received-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,count(service) as numservices from appointments '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.customer]

  }

  get_previous_services_received_by_month(query).then(function(){
    res.json(previous_services_received_by_month)
  });
});

router.route('/find-previous-services-received-by-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-services-received-by-service',
    text: 'select servicename,count(service) as numservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by servicename;',
    values: [req.body.customer]

  }

  get_previous_services_received_by_service(query).then(function(){
    res.json(previous_services_received_by_service)
  });
});

router.route('/find-amount-paid-for-previous-services-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-amount-paid-for-previous-services-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,sum(servicecost) as costservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.customer]

  }

  get_amount_paid_for_previous_services_by_month(query).then(function(){
    res.json(amount_paid_for_previous_services)
  });
});

router.route('/find-previous-services-provided-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-services-provided-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,count(service) as numservices from appointments '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.serviceprovider]

  }

  get_previous_services_provided_by_month(query).then(function(){
    res.json(previous_services_provided_by_month)
  });
});

router.route('/find-previous-services-provided-by-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-previous-services-provided-by-service',
    text: 'select servicename,count(service) as numservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by servicename;',
    values: [req.body.serviceprovider]

  }

  get_previous_services_provided_by_service(query).then(function(){
    res.json(previous_services_provided_by_service)
  });
});

router.route('/find-amount-received-for-previous-services-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-amount-received-for-previous-services-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,sum(servicecost) as costservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime < CURRENT_TIME) OR dayserviceperformed < CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.serviceprovider]

  }

  get_amount_received_for_previous_services_by_month(query).then(function(){
    res.json(amount_received_for_previous_services)
  });
});

router.route('/find-future-services-received-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-future-services-received-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,count(service) as numservices from appointments '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.customer]

  }

  get_future_services_received_by_month(query).then(function(){
    res.json(future_services_received_by_month)
  });
});

router.route('/find-future-services-received-by-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-future-services-received-by-service',
    text: 'select servicename,count(service) as numservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by servicename;',
    values: [req.body.customer]

  }

  get_future_services_received_by_service(query).then(function(){
    res.json(future_services_received_by_service)
  });
});

router.route('/find-amount-paid-for-future-services-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-amount-paid-for-future-services-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,sum(servicecost) as costservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE customer = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.customer]

  }

  get_amount_paid_for_future_services_by_month(query).then(function(){
    res.json(amount_paid_for_future_services)
  });
});

router.route('/find-future-services-provided-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-future-services-provided-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,count(service) as numservices from appointments '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.serviceprovider]

  }

  get_future_services_provided_by_month(query).then(function(){
    res.json(future_services_provided_by_month)
  });
});

router.route('/find-future-services-provided-by-service').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-future-services-provided-by-service',
    text: 'select servicename,count(service) as numservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by servicename;',
    values: [req.body.serviceprovider]

  }

  get_future_services_provided_by_service(query).then(function(){
    res.json(future_services_provided_by_service)
  });
});

router.route('/find-amount-received-for-future-services-by-month').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-amount-received-for-future-services-by-month',
    text: 'select EXTRACT(month from dayserviceperformed) as month,EXTRACT(year from dayserviceperformed) as year,sum(servicecost) as costservices from appointments NATURAL JOIN ServiceIDs '+
          'WHERE serviceprovider = $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by EXTRACT(month from dayserviceperformed),EXTRACT(year from dayserviceperformed);',
    values: [req.body.serviceprovider]

  }

  get_amount_received_for_future_services_by_month(query).then(function(){
    res.json(amount_received_for_future_services)
  });
});

router.route('/get-most-popular-services').get((req, res) => {
  const query = {
    name: 'get-most-popular-services',
    text: 'select serviceprovider, costperhour, servicename, appointments.service from serviceIDs natural join appointments left join services on Appointments.serviceprovider = Services.username and Services.service = Appointments.service group by serviceprovider, costperhour, servicename, Appointments.service order by count(*) desc limit 5;',
  }

  get_most_popular_services(query).then(function(){
    res.json(most_popular_services)
  });
});

router.route('/find-all-service-providers').get((req, res) => {
  const query = {
    name: 'find-all-service-providers',
    text: "SELECT DISTINCT username FROM Users WHERE type='Service Provider' ORDER BY username;",
  }

  get_all_service_providers(query).then(function(){
    res.json(all_service_providers_found)
  });
});

router.route('/find-all-services').get((req, res) => {
  const query = {
    name: 'find-all-services',
    text: "SELECT servicename FROM ServiceIDs ORDER BY servicename;",
  }

  get_all_services(query).then(function(){
    res.json(all_services_found)
  });
});

router.route('/find-all-service-ids').get((req, res) => {
  const query = {
    name: 'find-all-service-ids',
    text: "SELECT * FROM ServiceIDs;",
  }

  get_all_service_ids(query).then(function(){
    res.json(all_service_ids_found)
  });
});

router.route('/get-service-id').post((req, res) => {
  const query = {
    name: 'get-service-id',
    text: "SELECT * FROM ServiceIDs WHERE servicename = $1;",
    values: [req.body.service]
  }

  get_service_id(query).then(function(){
    res.json(service_id)
  });
});

router.route('/get-number-of-services-provided').get((req, res) => {
  const query = {
    name: 'get-number-of-services-provided',
    text: "SELECT servicename, count(servicename) as numservices from Appointments NATURAL JOIN ServiceIDs GROUP BY servicename Order By numservices desc limit 5;",
  }

  get_number_of_services_provided(query).then(function(){
    res.json(number_of_services_provided)
  });
});

router.route('/get-service-revenue').get((req, res) => {
  const query = {
    name: 'get-service-revenue',
    text: "SELECT servicename, sum(servicecost) as servicerevenue from Appointments NATURAL JOIN ServiceIDs GROUP BY servicename Order By servicerevenue desc limit 5;",
  }

  get_service_revenue(query).then(function(){
    res.json(service_revenue)
  });
});

router.route('/find-future-services-by-day').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-future-services-by-day',
    text: "select dayserviceperformed, count(dayserviceperformed) as numappointments, sum(servicecost) as totalcost from appointments "+
          "where serviceprovider= $1 AND ((dayserviceperformed = CURRENT_DATE AND servicestarttime >= CURRENT_TIME) OR dayserviceperformed > CURRENT_DATE) group by dayserviceperformed order by dayserviceperformed;",
    values: [req.body.serviceprovider]

  }

  get_future_services_by_day(query).then(function(){
    res.json(future_services_per_day)
  });
});

router.route('/find-appointments-by-date-time').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-appointments-by-date-time',
    text: "select * from appointments where dayserviceperformed = $1 and serviceprovider = $2 and (($3 <= servicestarttime and $4 >= servicestarttime) or ($3 >= servicestarttime and $3 <= serviceendtime));",
    values: [req.body.date, req.body.serviceprovider, req.body.servicestarttime, req.body.serviceendtime]

  }

  get_appointments_by_date_time(query).then(function(){
    res.json(appointments_by_date_time)
  });
});

router.route('/find-hardware-stores').get((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-hardware-stores',
    //8046.72 meters in 5 miles
    //Search radius is 5 miles
    text: 'SELECT * from hardwareStoreLocations WHERE ST_DWithin(hardwareStoreLocations.storelocation, ST_MakePoint(-87.627472, 41.838902), 8046.72) ORDER BY (hardwareStoreLocations.storelocation <-> ST_POINT(-87.627472, 41.838902));',
  }

  get_hardware_stores(query).then(function(){
    res.json(hardware_stores_found)
  });
});

//Returns types of services received by customer
router.route('/find-services-provided-to-customer').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-services-provided-to-customer',
    text: 'SELECT distinct service FROM Appointments WHERE customer = $1;',
    values: [req.body.customer]
  }

  get_services_provided_to_customer(query).then(function(){
    res.json(services_provided_to_customer)
  });
});

router.route('/find-services-scheduled-by-customer').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'find-services-scheduled-by-customer',
    text: 'select serviceprovider, costperhour, servicename, appointments.service from serviceIDs natural join appointments left join services on Appointments.serviceprovider = Services.username and Services.service = Appointments.service '+
          'where customer = $1 group by serviceprovider, costperhour, servicename, Appointments.service;',
    values: [req.body.customer]

  }

  get_services_scheduled_by_customer(query).then(function(){
    res.json(services_scheduled_by_customer)
  });
});

router.route('/add-customer-location').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'add-customer-location',
    text: 'INSERT INTO customerlocation(username, userlocation, longitude, latitude) VALUES ($1, ST_MakePoint($2,$3),$2,$3);',
    values: [req.body.username, req.body.longitude, req.body.latitude]
  }

  add_customer_location(query).then(function(){
    res.json(customer_location_added);
  });
});

router.route('/add-service-provider-location').post((req, res) => {
  JSON.stringify(req.body, null, 4);

  const query = {
    name: 'add-service-provider-location',
    text: 'INSERT INTO serviceproviderlocation(username, userlocation, longitude, latitude) VALUES ($1, ST_MakePoint($2,$3),$2,$3);',
    values: [req.body.username, req.body.longitude, req.body.latitude]
  }

  add_service_provider_location(query).then(function(){
    res.json(service_provider_location_added);
  });
});



async function get_users() { 
  const response = await pgClient.query('SELECT * from Users');
  users_found = [];
  for (i=0; i<response.rows.length; i++){
    var user = {
      "name": response.rows[i].username,
      "password": response.rows[i].password,
      "type": response.rows[i].type
    };
    users_found.push(user);
  }
}

async function get_user(query) { 
  const response = await pgClient.query(query);
  user_found = [];
  if(response.rows.length != 0){
    var user = {
      "username": response.rows[0].username,
      "password": response.rows[0].password,
      "type": response.rows[0].type
    };
    user_found.push(user);
  }
}

async function add_user(query) { 
  try{
    await pgClient.query(query);
    added = true;
  }catch(error){
    console.log(error.stack);
    added = false;
  }
}

async function get_user_info(query) { 
  const response = await pgClient.query(query);
  user_info = null;
  if(response.rows.length != 0){
    var user = {
      "name": response.rows[0].username,
      "password": response.rows[0].password,
      "type": response.rows[0].type,
      "streetAddress": response.rows[0].streetaddress,
      "city": response.rows[0].city,
      "state": response.rows[0].state,
      "zipCode": response.rows[0].zipcode,
      "email": response.rows[0].email,
      "phoneNumber": response.rows[0].phonenumber
    };
    user_info = user;
  }
}

async function update_user(query) { 
  try{
    await pgClient.query(query);
    updated = true;
  }catch(error){
    console.log(error.stack);
    updated = false;
  }
}

async function get_customer_future_appointments(query){
  const response = await pgClient.query(query);
  appointments_found = [];
  for(i=0; i<response.rows.length; i++){
    var appointment = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime,
      "serviceProvider": response.rows[i].serviceprovider,
      "serviceCost": response.rows[i].servicecost,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode
    }
    appointments_found.push(appointment);
  }
}

async function delete_appointment(query){
  try{
    await pgClient.query(query);
    deleted = true;
  }catch(error){
    console.log(error.stack);
    deleted = false;
  }
}

async function update_appointment(query){
  try{
    await pgClient.query(query);
    updated = true;
  }catch(error){
    console.log(error.stack);
    updated = false;
  }
}

async function get_customer_previous_appointments(query){
  const response = await pgClient.query(query);
  appointments_found = [];
  for(i=0; i<response.rows.length; i++){
    var appointment = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime,
      "serviceProvider": response.rows[i].serviceprovider,
      "serviceCost": response.rows[i].servicecost,
      "amountDue": response.rows[i].amountdue,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode
    }
    appointments_found.push(appointment);
  }
}

async function make_payment(query){
  try{
    await pgClient.query(query);
    payment_made = true;
  }catch(error){
    console.log(error.stack);
    payment_made = false;
  }
}

async function get_service_providers(query){
  const response = await pgClient.query(query);
  service_providers_found = [];
  for(i=0; i<response.rows.length; i++){
    var serviceProvider = {
      "name": response.rows[i].username,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "latitude": response.rows[i].latitude,
      "longitude": response.rows[i].longitude,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode,
      "costPerHour": response.rows[i].costperhour,
      "email": response.rows[i].email,
      "phoneNumber": response.rows[i].phonenumber
    }
    service_providers_found.push(serviceProvider);
  }
}

async function get_service_cost(query){
  const response = await pgClient.query(query);
  service_cost = null;
  if(response.rows.length != 0){
    service_cost = response.rows[0].costperhour
  }
}

async function get_user_address(query){
  const response = await pgClient.query(query);
  user_address = null;
  if(response.rows.length != 0){
    var user = {
      "streetAddress": response.rows[0].streetaddress,
      "city": response.rows[0].city,
      "state": response.rows[0].state,
      "zipCode": response.rows[0].zipcode
    }
    user_address = user;
  }
}

async function add_appopintment_to_cart(query){
  try{
    await pgClient.query(query);
    added_to_cart = true;
  }catch(error){
    console.log(error.stack);
    added_to_cart = false;
  }
}

async function get_cart_items(){
  const response = await pgClient.query('SELECT * from Cart NATURAL JOIN ServiceIDs');
  cart_items = [];
  for (i=0; i<response.rows.length; i++){
    var cart_item = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime,
      "serviceProvider": response.rows[i].serviceprovider,
      "serviceCost": response.rows[i].servicecost,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode
    };
    cart_items.push(cart_item);
  }
  
}

async function remove_cart_item(query){
  try{
    await pgClient.query(query);
    removed_from_cart = true;
  }catch(error){
    console.log(error.stack);
    removed_from_cart = false;
  }
}

async function create_appointment(query){
  try{
    await pgClient.query(query);
    appointment_created = true;
  }catch(error){
    console.log(error.stack);
    appointment_created = false;
  }
}

async function clear_cart(){
  try{
    await pgClient.query('DELETE from Cart');
    cart_cleared = true;
  }catch(error){
    console.log(error.stack);
    cart_cleared = false;
  }
}

async function create_service(query){
  try{
    await pgClient.query(query);
    service_added = true;
  }catch(error){
    console.log(error.stack);
    service_added = false;
  }
}

async function get_current_services(query){
  const response = await pgClient.query(query);
  current_services = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "service": response.rows[i].service,
      "costPerHour": response.rows[i].costperhour
    }
    current_services.push(service);
  }
}

async function remove_service(query){
  try{
    await pgClient.query(query);
    service_deleted = true;
  }catch(error){
    console.log(error.stack);
    service_deleted = false;
  }
}

async function get_service_provider_previous_appointments(query){
  const response = await pgClient.query(query);
  previous_service_provider_appointments_found = [];
  for(i=0; i<response.rows.length; i++){
    var appointment = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime,
      "customer": response.rows[i].customer,
      "serviceCost": response.rows[i].servicecost,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode
    }
    previous_service_provider_appointments_found.push(appointment);
  }
}

async function get_service_provider_future_appointments(query){
  const response = await pgClient.query(query);
  future_service_provider_appointments_found = [];
  for(i=0; i<response.rows.length; i++){
    var appointment = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime,
      "customer": response.rows[i].customer,
      "serviceCost": response.rows[i].servicecost,
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode
    }
    future_service_provider_appointments_found.push(appointment);
  }
}

async function get_previous_service_providers(query){
  const response = await pgClient.query(query);
  previous_service_providers_found = [];
  for (i=0; i<response.rows.length; i++){
    var service_provider = {
      "name": response.rows[i].serviceprovider,
      "service": response.rows[i].service
    };
    previous_service_providers_found.push(service_provider);
  }
}

async function check_if_user_exists(query){
  const response = await pgClient.query(query);
  users_found_with_username = null;
  if(response.rows.length != 0){
    users_found_with_username = response.rows[0].count
  }
}

async function get_services_provided(query){
  const response = await pgClient.query(query);
  services_provided = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "service": response.rows[i].service,
      "serviceName": response.rows[i].servicename
    };
    services_provided.push(service);
  }
}

async function get_video_ids(query){
  const response = await pgClient.query(query);
  video_ids = [];
  for (i=0; i<response.rows.length; i++){
    var id = {
      "videoId": response.rows[i].videoid,
    };
    video_ids.push(id);
  }
}

async function get_previous_services_received_by_month(query){
  const response = await pgClient.query(query);
  previous_services_received_by_month = [];
  for (i=0; i<response.rows.length; i++){
    var month = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "numServices": response.rows[i].numservices,
    };
    previous_services_received_by_month.push(month);
  }
}

async function get_previous_services_received_by_service(query){ 
  const response = await pgClient.query(query);
  previous_services_received_by_service = [];
  for (i=0; i<response.rows.length; i++){
    var prev_service = {
      "serviceName": response.rows[i].servicename,
      "numServices": response.rows[i].numservices
    };
    previous_services_received_by_service.push(prev_service);
  }
}

async function get_amount_paid_for_previous_services_by_month(query){
  const response = await pgClient.query(query);
  amount_paid_for_previous_services = [];
  for (i=0; i<response.rows.length; i++){
    var prev_service = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "costServices": response.rows[i].costservices
    };
    amount_paid_for_previous_services.push(prev_service);
  }
}

async function get_previous_services_provided_by_month(query){
  const response = await pgClient.query(query);
  previous_services_provided_by_month = [];
  for (i=0; i<response.rows.length; i++){
    var month = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "numServices": response.rows[i].numservices,
    };
    previous_services_provided_by_month.push(month);
  }
}

async function  get_previous_services_provided_by_service(query){
  const response = await pgClient.query(query);
  previous_services_provided_by_service = [];
  for (i=0; i<response.rows.length; i++){
    var prev_service = {
      "serviceName": response.rows[i].servicename,
      "numServices": response.rows[i].numservices
    };
    previous_services_provided_by_service.push(prev_service);
  }
}

async function get_amount_received_for_previous_services_by_month(query){
  const response = await pgClient.query(query);
  amount_received_for_previous_services = [];
  for (i=0; i<response.rows.length; i++){
    var prev_service = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "costServices": response.rows[i].costservices
    };
    amount_received_for_previous_services.push(prev_service);
  }
}

async function get_future_services_received_by_month(query){
  const response = await pgClient.query(query);
  future_services_received_by_month = [];
  for (i=0; i<response.rows.length; i++){
    var month = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "numServices": response.rows[i].numservices,
    };
    future_services_received_by_month.push(month);
  }
}

async function get_future_services_received_by_service(query){
  const response = await pgClient.query(query);
  future_services_received_by_service = [];
  for (i=0; i<response.rows.length; i++){
    var future_service = {
      "serviceName": response.rows[i].servicename,
      "numServices": response.rows[i].numservices
    };
    future_services_received_by_service.push(future_service);
  }
}

async function get_amount_paid_for_future_services_by_month(query){
  const response = await pgClient.query(query);
  amount_paid_for_future_services = [];
  for (i=0; i<response.rows.length; i++){
    var future_service = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "costServices": response.rows[i].costservices
    };
    amount_paid_for_future_services.push(future_service);
  }
}

async function get_future_services_provided_by_month(query){
  const response = await pgClient.query(query);
  future_services_provided_by_month = [];
  for (i=0; i<response.rows.length; i++){
    var month = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "numServices": response.rows[i].numservices,
    };
    future_services_provided_by_month.push(month);
  }
}

async function get_future_services_provided_by_service(query){
  const response = await pgClient.query(query);
  future_services_provided_by_service = [];
  for (i=0; i<response.rows.length; i++){
    var future_service = {
      "serviceName": response.rows[i].servicename,
      "numServices": response.rows[i].numservices
    };
    future_services_provided_by_service.push(future_service);
  }
}

async function get_amount_received_for_future_services_by_month(query){
  const response = await pgClient.query(query);
  amount_received_for_future_services = [];
  for (i=0; i<response.rows.length; i++){
    var future_service = {
      "month": response.rows[i].month,
      "year": response.rows[i].year,
      "costServices": response.rows[i].costservices
    };
    amount_received_for_future_services.push(future_service);
  }
}

async function get_most_popular_services(query){
  const response = await pgClient.query(query);
  most_popular_services = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "serviceProvider": response.rows[i].serviceprovider,
      "costPerHour": response.rows[i].costperhour,
      "serviceName": response.rows[i].servicename,
      "service": response.rows[i].service,
    };
    most_popular_services.push(service);
  }
}

async function get_all_service_providers(query){
  const response = await pgClient.query(query);
  all_service_providers_found = [];
  for (i=0; i<response.rows.length; i++){
    all_service_providers_found.push(response.rows[i].username);
  }
}

async function get_all_services(query){
  const response = await pgClient.query(query);
  all_services_found = [];
  for (i=0; i<response.rows.length; i++){
    all_services_found.push(response.rows[i].servicename);
  }
}

async function get_all_service_ids(query){
  const response = await pgClient.query(query);
  all_service_ids_found = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "serviceName": response.rows[i].servicename,
      "service": response.rows[i].service
    };
    all_service_ids_found.push(service);
  }
}

async function get_service_id(query){
  const response = await pgClient.query(query);
  service_id = null;
  if(response.rows.length != 0){
      service_id = response.rows[0].service;
  }
}

async function get_number_of_services_provided(query){
  const response = await pgClient.query(query);
  number_of_services_provided = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "serviceName": response.rows[i].servicename,
      "numServices": response.rows[i].numservices
    };
    number_of_services_provided.push(service);
  }
}

async function get_service_revenue(query){
  const response = await pgClient.query(query);
  service_revenue = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "serviceName": response.rows[i].servicename,
      "serviceRevenue": response.rows[i].servicerevenue
    };
    service_revenue.push(service);
  }
}

async function get_future_services_by_day(query){
  const response = await pgClient.query(query);
  future_services_per_day = [];
  for (i=0; i<response.rows.length; i++){
    var services_per_day = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "numAppointments": response.rows[i].numappointments,
      "totalCost": response.rows[i].totalcost
    };
    future_services_per_day.push(services_per_day);
  }
}

async function get_appointments_by_date_time(query){
  const response = await pgClient.query(query);
  appointments_by_date_time = [];
  for (i=0; i<response.rows.length; i++){
    var appointment = {
      "dayServicePerformed": response.rows[i].dayserviceperformed,
      "serviceStartTime": response.rows[i].servicestarttime,
      "serviceEndTime": response.rows[i].serviceendtime
    };
    appointments_by_date_time.push(appointment);
  }
}

async function get_hardware_stores(query){
  const response = await pgClient.query(query);
  hardware_stores_found = [];
  for (i=0; i<response.rows.length; i++){
    var store = {
      "storeName": response.rows[i].storename,
      "latitude": response.rows[i].latitude,
      "longitude": response.rows[i].longitude,
      "streetAddress": response.rows[i].streetaddress,
      "city": response.rows[i].city,
      "state": response.rows[i].state,
      "zipCode": response.rows[i].zipcode,
      "phoneNumber": response.rows[i].phonenumber
    };
    hardware_stores_found.push(store);
  }
}

async function get_services_provided_to_customer(query){
  const response = await pgClient.query(query);
  services_provided_to_customer = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "service": response.rows[i].service
    };
    services_provided_to_customer.push(service);
  }
}

async function get_services_scheduled_by_customer(query){
  const response = await pgClient.query(query);
  services_scheduled_by_customer = [];
  for (i=0; i<response.rows.length; i++){
    var service = {
      "name": response.rows[i].serviceprovider,
      "costPerHour": response.rows[i].costperhour,
      "serviceName": response.rows[i].servicename,
      "service": response.rows[i].service,
    };
    services_scheduled_by_customer.push(service);
  }
}

async function add_customer_location(query){
  try{
    await pgClient.query(query);
    customer_location_added = true;
  }catch(error){
    console.log(error.stack);
    customer_location_added = false;
  }
}

async function add_service_provider_location(query){
  try{
    await pgClient.query(query);
    service_provider_location_added = true;
  }catch(error){
    console.log(error.stack);
    service_provider_location_added = false;
  }
}