create table Users(
	username varchar(80),
	password varchar(40),
	type varchar(20),
	streetaddress varchar(60),
	city varchar(20),
	state varchar(20),
	zipcode int,
	email varchar(50),
	phonenumber bigint,
	primary key(username)
);

CREATE TABLE Services(
	username varchar(80),
	service varchar(60),
	costperhour money,
	primary key(username, service),
	foreign key(username) REFERENCES Users(username)
);

CREATE TABLE Appointments(
	dayserviceperformed date,
	servicestarttime time without time zone,
	serviceendtime time without time zone,
	serviceprovider varchar(80),
	customer varchar(40),
	servicecost money,
	amountdue money,
	service varchar(40),
	streetaddress varchar(40),
	city varchar(20),
	state varchar(20),
	zipcode int,
	primary key(customer, serviceprovider, dayserviceperformed, servicestarttime),
	FOREIGN KEY (customer) REFERENCES Users(username),
	FOREIGN KEY (serviceprovider, service) REFERENCES Services(username, service)
);

CREATE EXTENSION postgis;

CREATE TABLE serviceProviderLocation (
  	username varchar(80),
	userlocation geography,
	latitude DOUBLE PRECISION,
	longitude DOUBLE PRECISION,
	primary key(username),
	foreign key(username) references Users(username)
);

CREATE TABLE customerLocation (
  	username varchar(40),
	userlocation geography,
	latitude DOUBLE PRECISION,
	longitude DOUBLE PRECISION,
	primary key(username),
	foreign key(username) references Users(username)
);

CREATE TABLE cart (
	dayserviceperformed date,
	servicestarttime time without time zone,
	serviceendtime time without time zone,
	serviceprovider varchar(80),
	servicecost money,
	service varchar(40),
	streetaddress varchar(40),
	city varchar(20),
	state varchar(20),
	zipcode int,
	primary key(serviceprovider, dayserviceperformed, servicestarttime),
	FOREIGN KEY (serviceprovider, service) REFERENCES Services(username, service)
);

CREATE TABLE ServiceIDs(
	service varchar(60),
	servicename varchar(60),
	primary key(service)
);

CREATE TABLE YoutubeVideos(
	type varchar(40),
	videoid varchar(40),
	primary key(videoId)
);

CREATE TABLE hardwareStoreLocations(
	storename varchar(60),
	streetaddress varchar(60),
	city varchar(20),
	state varchar(20),
	zipcode int,
	phonenumber bigint,
	storelocation geography,
	latitude DOUBLE PRECISION,
	longitude DOUBLE PRECISION,
	primary key(storeName)
);